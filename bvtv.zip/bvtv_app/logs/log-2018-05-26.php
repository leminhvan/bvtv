<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-26 02:20:27 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:20:27 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:20:42 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:20:42 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:20:45 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:20:45 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:20:58 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 02:20:58 --> Could not find the language line "last_name"
ERROR - 2018-05-26 02:20:58 --> Could not find the language line "groups"
ERROR - 2018-05-26 02:20:58 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:20:58 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:21:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:21:15 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:24:19 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:24:19 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:24:25 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:24:25 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:29:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:29:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:29:50 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 02:29:50 --> Could not find the language line "last_name"
ERROR - 2018-05-26 02:29:50 --> Could not find the language line "groups"
ERROR - 2018-05-26 02:29:50 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:29:50 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:30:02 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 02:30:02 --> Could not find the language line "last_name"
ERROR - 2018-05-26 02:30:02 --> Could not find the language line "groups"
ERROR - 2018-05-26 02:30:02 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:30:02 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:30:10 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 02:30:10 --> Could not find the language line "last_name"
ERROR - 2018-05-26 02:30:10 --> Could not find the language line "groups"
ERROR - 2018-05-26 02:30:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:30:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:30:30 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:30:30 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:33:07 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:33:08 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:33:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:33:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:33:24 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:33:24 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:34:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:34:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:42:52 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 02:42:52 --> Could not find the language line "last_name"
ERROR - 2018-05-26 02:42:52 --> Could not find the language line "groups"
ERROR - 2018-05-26 02:42:53 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:42:53 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:50:03 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 02:50:03 --> Could not find the language line "last_name"
ERROR - 2018-05-26 02:50:03 --> Could not find the language line "groups"
ERROR - 2018-05-26 02:50:03 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:50:03 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:50:06 --> 404 Page Not Found: /index
ERROR - 2018-05-26 02:50:07 --> 404 Page Not Found: /index
ERROR - 2018-05-26 10:11:41 --> Could not find the language line "hcgoc_manufac"
ERROR - 2018-05-26 10:11:41 --> Could not find the language line "hcgoc_percent"
ERROR - 2018-05-26 10:12:35 --> Could not find the language line "hcgoc_manufac"
ERROR - 2018-05-26 10:12:35 --> Could not find the language line "hcgoc_percent"
ERROR - 2018-05-26 10:12:46 --> Could not find the language line "hcgoc_manufac"
ERROR - 2018-05-26 10:12:46 --> Could not find the language line "hcgoc_percent"
ERROR - 2018-05-26 10:18:40 --> Could not find the language line "hcgoc_manufac"
ERROR - 2018-05-26 10:18:40 --> Could not find the language line "hcgoc_percent"
ERROR - 2018-05-26 03:46:33 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:46:33 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:46:33 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:46:33 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:46:33 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:46:48 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:46:48 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:46:48 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:46:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:46:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:47:04 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:47:04 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:47:04 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:47:04 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:47:04 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:47:48 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:47:48 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:47:48 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:47:48 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:47:48 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:49:02 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:49:02 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:49:02 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:49:03 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:49:03 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:50:29 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:50:29 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:50:29 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:50:29 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:50:30 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:52:46 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:52:46 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:52:46 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:52:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:52:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:53:56 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:53:56 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:53:56 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:53:57 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:53:57 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:54:20 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:54:20 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:54:20 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:54:21 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:54:21 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:54:43 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 03:54:43 --> Could not find the language line "last_name"
ERROR - 2018-05-26 03:54:43 --> Could not find the language line "groups"
ERROR - 2018-05-26 03:54:44 --> 404 Page Not Found: /index
ERROR - 2018-05-26 03:54:44 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:03:10 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:03:10 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:03:10 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:05:51 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:05:51 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:05:51 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:05:51 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:05:51 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:06:16 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:06:16 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:06:16 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:06:17 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:06:17 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:07:10 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:07:10 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:07:10 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:07:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:07:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:23:00 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:23:00 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:23:18 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:23:18 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:23:31 --> Severity: Error --> Cannot use object of type Ion_auth_model as array D:\HOST\www\bvtv\bvtv_app\modules\hoachat\controllers\Chuangoc.php 23
ERROR - 2018-05-26 04:23:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:23:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:25:27 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:25:28 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:25:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:25:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:25:59 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:25:59 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:26:05 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:26:05 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:26:19 --> Severity: Error --> Call to undefined method Ion_auth_model::rows() D:\HOST\www\bvtv\bvtv_app\modules\hoachat\controllers\Chuangoc.php 23
ERROR - 2018-05-26 04:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:27:53 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:28:09 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:28:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:39:41 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:39:41 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:39:41 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:39:41 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:39:41 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:40:42 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:40:42 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:40:54 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:40:54 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:41:41 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:41:41 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:42:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:42:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:42:18 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:42:18 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:42:18 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:42:19 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:42:19 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:42:46 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:42:46 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:42:46 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:42:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:42:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:42:57 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:43:29 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:43:29 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:43:37 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:43:37 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:43:37 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:43:38 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:43:38 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:43:45 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:43:45 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:43:45 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:43:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:43:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:02 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:02 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:09 --> Could not find the language line "Menu Title"
ERROR - 2018-05-26 04:44:09 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-26 04:44:09 --> Could not find the language line "Menu Url"
ERROR - 2018-05-26 04:44:09 --> Could not find the language line "Menu Index"
ERROR - 2018-05-26 04:44:09 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-26 04:44:09 --> Could not find the language line "Phanquyen"
ERROR - 2018-05-26 04:44:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:28 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:43 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:43 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:52 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:44:52 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:44:52 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:44:52 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:44:52 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:45:01 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-26 04:45:01 --> Could not find the language line "last_name"
ERROR - 2018-05-26 04:45:01 --> Could not find the language line "groups"
ERROR - 2018-05-26 04:45:01 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:45:01 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:45:04 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:45:09 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:55:15 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:55:18 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:55:20 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:55:21 --> 404 Page Not Found: /index
ERROR - 2018-05-26 04:55:21 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:51:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php:132) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-26 05:51:41 --> Severity: Parsing Error --> syntax error, unexpected '{' D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 132
ERROR - 2018-05-26 05:52:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:52:44 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:52:45 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:52:45 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:53:54 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:53:54 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:53:55 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:53:58 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:55:18 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:55:19 --> 404 Page Not Found: /index
ERROR - 2018-05-26 05:55:19 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:05:35 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:05:36 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:05:36 --> 404 Page Not Found: /index
ERROR - 2018-05-26 13:08:14 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:08:14 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:08:14 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:08:14 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:08:14 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 06:08:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:08:15 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:08:15 --> 404 Page Not Found: /index
ERROR - 2018-05-26 13:08:53 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:08:53 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:08:53 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:08:53 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:08:53 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 06:08:53 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:08:54 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:08:54 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:09:58 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:09:59 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:09:59 --> 404 Page Not Found: /index
ERROR - 2018-05-26 13:12:02 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:12:02 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:12:02 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:12:02 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:12:02 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 06:12:02 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:12:03 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:12:03 --> 404 Page Not Found: /index
ERROR - 2018-05-26 13:12:22 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:12:22 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:12:22 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:12:22 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 13:12:22 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 155
ERROR - 2018-05-26 06:12:22 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:12:23 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:12:23 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:13:28 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:13:28 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:13:29 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:13:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:13:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:13:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:14:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:14:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:14:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:41:02 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:41:03 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:41:03 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:41:06 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:42:59 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:43:01 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:43:45 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:43:47 --> Severity: Notice --> Undefined index: module_id D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 165
ERROR - 2018-05-26 06:43:47 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:43:48 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:43:48 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:11 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:12 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:12 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:36 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 165
ERROR - 2018-05-26 06:45:36 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:36 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:36 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:48 --> Severity: Notice --> Undefined index: module_id D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 165
ERROR - 2018-05-26 06:45:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:45:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:46:13 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:46:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:46:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:47:05 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:47:06 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:47:06 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:47:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 168
ERROR - 2018-05-26 06:47:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:47:57 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:47:57 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:49:38 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:49:38 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:49:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 13:52:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:52:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:52:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:52:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:52:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:52:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:52:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:52:56 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 06:52:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:52:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:52:57 --> 404 Page Not Found: /index
ERROR - 2018-05-26 13:53:29 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:53:29 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:53:29 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:53:29 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:53:29 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:53:29 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:53:29 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 13:53:29 --> Severity: Notice --> Undefined offset: 1 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 154
ERROR - 2018-05-26 06:53:29 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:53:29 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:53:30 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:55:05 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:55:05 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:55:06 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:55:09 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:55:09 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:55:09 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:57:04 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:57:05 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:57:05 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:57:32 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:57:33 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:57:33 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:59:17 --> 404 Page Not Found: /index
ERROR - 2018-05-26 06:59:17 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:02:39 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 168
ERROR - 2018-05-26 07:02:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:02:40 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:02:40 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:03:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:03:15 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:03:15 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:04:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:04:39 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:04:48 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:04:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:04:49 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:05:33 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:05:33 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:05:40 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:05:40 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:05:43 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:05:44 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:05:44 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:06:01 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:06:02 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:06:02 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:07:50 --> Severity: Parsing Error --> syntax error, unexpected '{' D:\HOST\www\bvtv\bvtv_app\modules\hoachat\controllers\Chuangoc.php 37
ERROR - 2018-05-26 07:08:56 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:09:00 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:14:40 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:14:47 --> Could not find the language line "module_name"
ERROR - 2018-05-26 07:14:47 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:14:47 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:14:53 --> Could not find the language line "module_name"
ERROR - 2018-05-26 07:17:57 --> Could not find the language line "Menu Title"
ERROR - 2018-05-26 07:17:57 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-26 07:17:57 --> Could not find the language line "Menu Url"
ERROR - 2018-05-26 07:17:57 --> Could not find the language line "Menu Index"
ERROR - 2018-05-26 07:17:57 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-26 07:17:57 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\models\Menu_model.php 200
ERROR - 2018-05-26 07:17:57 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:17:58 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:19:12 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:19:12 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:19:18 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:19:18 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:19:27 --> Could not find the language line "Menu Title"
ERROR - 2018-05-26 07:19:27 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-26 07:19:27 --> Could not find the language line "Menu Url"
ERROR - 2018-05-26 07:19:27 --> Could not find the language line "Menu Index"
ERROR - 2018-05-26 07:19:27 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-26 07:19:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\models\Menu_model.php 200
ERROR - 2018-05-26 07:19:28 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:19:28 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:20:08 --> Could not find the language line "Menu Title"
ERROR - 2018-05-26 07:20:08 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-26 07:20:08 --> Could not find the language line "Menu Url"
ERROR - 2018-05-26 07:20:08 --> Could not find the language line "Menu Index"
ERROR - 2018-05-26 07:20:09 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-26 07:21:14 --> Could not find the language line "Menu Title"
ERROR - 2018-05-26 07:21:14 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-26 07:21:14 --> Could not find the language line "Menu Url"
ERROR - 2018-05-26 07:21:14 --> Could not find the language line "Menu Index"
ERROR - 2018-05-26 07:21:14 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-26 07:21:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\models\Menu_model.php 200
ERROR - 2018-05-26 07:21:15 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:21:15 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:21:59 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 60
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 44
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: i D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 46
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 48
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 49
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 50
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 51
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 52
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 53
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 55
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 55
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 56
ERROR - 2018-05-26 07:22:10 --> Severity: Notice --> Undefined variable: sys_menu D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\view.php 57
ERROR - 2018-05-26 07:22:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:22:10 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:22:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:22:46 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:24:14 --> 404 Page Not Found: /index
ERROR - 2018-05-26 07:24:14 --> 404 Page Not Found: /index
