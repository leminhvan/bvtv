<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-29 08:36:37 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-29 01:36:37 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:36:37 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:36:46 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-29 01:36:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:36:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:37:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:37:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:37:19 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:37:19 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:38:06 --> Could not find the language line "Menu Title"
ERROR - 2018-05-29 08:38:06 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-29 08:38:06 --> Could not find the language line "Menu Url"
ERROR - 2018-05-29 08:38:06 --> Could not find the language line "Menu Index"
ERROR - 2018-05-29 08:38:06 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-29 01:38:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:38:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:38:15 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:38:15 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:38:15 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:38:15 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:38:15 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:38:15 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:38:15 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:38:16 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:38:16 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:38:16 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:38:16 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:38:16 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:38:16 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:38:16 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:39:02 --> Could not find the language line "Menu Title"
ERROR - 2018-05-29 08:39:02 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-29 08:39:02 --> Could not find the language line "Menu Url"
ERROR - 2018-05-29 08:39:02 --> Could not find the language line "Menu Index"
ERROR - 2018-05-29 08:39:02 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-29 08:39:07 --> Could not find the language line "Menu Title"
ERROR - 2018-05-29 08:39:07 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-29 08:39:07 --> Could not find the language line "Menu Url"
ERROR - 2018-05-29 08:39:07 --> Could not find the language line "Menu Index"
ERROR - 2018-05-29 08:39:07 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-29 08:39:31 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-29 01:39:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:39:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:39:44 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-29 08:39:44 --> Could not find the language line "last_name"
ERROR - 2018-05-29 08:39:44 --> Could not find the language line "groups"
ERROR - 2018-05-29 01:39:44 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:39:44 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:41:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:41:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:41:21 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:41:21 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:41:21 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:41:21 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:41:21 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:41:21 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:41:21 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:41:23 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:41:23 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:41:23 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:41:23 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:41:23 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:41:23 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:41:23 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:41:27 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:41:27 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:41:27 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:41:27 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:41:27 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:41:27 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:41:27 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:41:29 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:41:29 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:41:29 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:41:29 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:41:29 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:41:29 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:41:29 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:42:07 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:42:19 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:42:19 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:42:19 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:42:19 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:42:19 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:42:19 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:42:19 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 01:42:39 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:42:39 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:42:43 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:42:43 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:42:51 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:42:51 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:42:51 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:42:51 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:42:51 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:42:51 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:42:51 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:42:53 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:42:53 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:42:53 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:42:53 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:42:53 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:42:53 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:42:53 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 01:43:07 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:43:07 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:43:15 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:43:15 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:43:15 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:43:15 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:43:15 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:43:16 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:43:17 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:43:17 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:43:17 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:43:17 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:43:17 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:43:17 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:43:17 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 01:43:18 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:43:18 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:53:41 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:53:41 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:54:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 01:54:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 08:57:11 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:57:11 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:57:11 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:57:11 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:57:11 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:57:11 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:57:11 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 08:57:41 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 25
ERROR - 2018-05-29 08:57:41 --> Severity: Notice --> Undefined index: menu_parent_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 41
ERROR - 2018-05-29 08:57:41 --> Severity: Notice --> Undefined index: menu_url D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 69
ERROR - 2018-05-29 08:57:41 --> Severity: Notice --> Undefined index: menu_index D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 91
ERROR - 2018-05-29 08:57:41 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 105
ERROR - 2018-05-29 08:57:41 --> Severity: Notice --> Undefined index: menu_icon D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 115
ERROR - 2018-05-29 08:57:41 --> Severity: Notice --> Undefined index: module_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\menu\form.php 137
ERROR - 2018-05-29 02:07:32 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:07:33 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:08:41 --> Could not find the language line "Menu Title"
ERROR - 2018-05-29 09:08:41 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-29 09:08:41 --> Could not find the language line "Menu Url"
ERROR - 2018-05-29 09:08:41 --> Could not find the language line "Menu Index"
ERROR - 2018-05-29 09:08:41 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-29 02:08:41 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:08:41 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:08:51 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:08:51 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:09:12 --> Could not find the language line "Menu Title"
ERROR - 2018-05-29 09:09:12 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-29 09:09:12 --> Could not find the language line "Menu Url"
ERROR - 2018-05-29 09:09:12 --> Could not find the language line "Menu Index"
ERROR - 2018-05-29 09:09:12 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-29 02:09:13 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:09:13 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:09:19 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-29 02:09:19 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:09:19 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:09:24 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:09:24 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:09:54 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:09:55 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:09:55 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:10:01 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:11:24 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:12:09 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:12:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:12:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:13:57 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:57 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:58 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 09:13:59 --> Severity: Notice --> Undefined variable: bvtv_tailieu_thamkhao D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 02:14:00 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:14:01 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:14:14 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:14:14 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:14:14 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:16:09 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:16:10 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:16:10 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:17:00 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:17:01 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:17:01 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:17:10 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:17:10 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:17:10 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:18:57 --> Severity: Notice --> Undefined variable: count_sop D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 44
ERROR - 2018-05-29 09:18:57 --> Severity: Notice --> Undefined variable: count_chidinh D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 37
ERROR - 2018-05-29 09:18:57 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:18:58 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:18:58 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:19:25 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:19:26 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:19:26 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:19:58 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:19:59 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:19:59 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:20:02 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:21:05 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:21:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:21:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:21:12 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:21:59 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:22:00 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:22:00 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:22:01 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:23:09 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:23:10 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:23:10 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:23:12 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:23:38 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:23:39 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:23:39 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:23:40 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:23:59 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:24:02 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:24:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:24:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:24:48 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:24:49 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:24:49 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:24:55 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:24:55 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:24:55 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:25:08 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:25:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:25:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:25:16 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:25:30 --> 404 Page Not Found: ../modules/thamkhao/controllers/Thamkhao/viewFile
ERROR - 2018-05-29 02:29:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:29:03 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/TCVN-9475_2012-Abamectin.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 283
ERROR - 2018-05-29 02:29:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:29:06 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/TCVN-9475_2012-Abamectin.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 283
ERROR - 2018-05-29 09:34:16 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:34:17 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:34:17 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:34:20 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:34:20 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/TCVN-9475_2012-Abamectin.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 279
ERROR - 2018-05-29 09:35:10 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:36:01 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:36:24 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:36:40 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:36:56 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:37:23 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:38:47 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:41:39 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:45:28 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:45:34 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:45:35 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:45:35 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:45:39 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:45:50 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:45:50 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:45:51 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:45:54 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:46:03 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:46:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:46:04 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:46:06 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 09:46:10 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:46:11 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:46:11 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:46:49 --> Could not find the language line "tk_code"
ERROR - 2018-05-29 02:48:42 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:48:42 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:53:52 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:53:52 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:54:14 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:54:14 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:55:37 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:55:38 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:56:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:56:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:56:30 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:56:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:57:05 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:57:05 --> 404 Page Not Found: /index
ERROR - 2018-05-29 02:57:10 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:04:49 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:04:49 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:16:22 --> Severity: Parsing Error --> syntax error, unexpected '',' (T_CONSTANT_ENCAPSED_STRING) D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 123
ERROR - 2018-05-29 03:16:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:16:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 10:44:15 --> Severity: Error --> Call to undefined function do_upload() D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 150
ERROR - 2018-05-29 03:45:37 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:45:37 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:46:07 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:46:07 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:46:24 --> 404 Page Not Found: /index
ERROR - 2018-05-29 10:46:24 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/test.pdf.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 284
ERROR - 2018-05-29 03:46:27 --> 404 Page Not Found: /index
ERROR - 2018-05-29 10:46:27 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/test.pdf.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 284
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:39 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:40 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:41 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:42 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:43 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 58
ERROR - 2018-05-29 10:51:44 --> Severity: Notice --> Undefined variable: a D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\view.php 61
ERROR - 2018-05-29 03:51:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:51:47 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:52:05 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:52:05 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:54:58 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:54:59 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:55:16 --> 404 Page Not Found: /index
ERROR - 2018-05-29 10:55:16 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/TC-75_97-CL-Alachlor.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 283
ERROR - 2018-05-29 03:58:02 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:58:02 --> 404 Page Not Found: /index
ERROR - 2018-05-29 03:58:08 --> 404 Page Not Found: /index
ERROR - 2018-05-29 10:58:08 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 283
ERROR - 2018-05-29 04:00:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:00:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:00:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:00:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:00:52 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:00:52 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 283
ERROR - 2018-05-29 04:01:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:01:06 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:05:19 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:05:19 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:05:39 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:05:39 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:05:52 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:05:52 --> Severity: Warning --> file_get_contents(http://localhost/bvtv/uploads/files/tltk/.pdf): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\controllers\Thamkhao.php 283
ERROR - 2018-05-29 04:06:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:06:47 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:09:05 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:09:05 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:09:20 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:09:20 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:09:57 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:09:57 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:12:08 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:12:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:12:21 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 04:12:22 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:12:22 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:12:44 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 04:12:45 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:12:45 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:13:08 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 04:13:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:13:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:19:40 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:19:40 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:20:59 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-29 11:20:59 --> Could not find the language line "last_name"
ERROR - 2018-05-29 11:20:59 --> Could not find the language line "groups"
ERROR - 2018-05-29 04:20:59 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:20:59 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:24:17 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:24:17 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:24:50 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 04:24:51 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:24:51 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:27:23 --> Severity: Notice --> Undefined variable: val D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\form.php 103
ERROR - 2018-05-29 11:27:23 --> Severity: Notice --> Undefined variable: val D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\form.php 107
ERROR - 2018-05-29 11:27:23 --> Severity: Notice --> Undefined variable: val D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\form.php 113
ERROR - 2018-05-29 11:27:23 --> Severity: Notice --> Undefined variable: val D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\form.php 119
ERROR - 2018-05-29 11:27:23 --> Severity: Notice --> Undefined variable: val D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\form.php 125
ERROR - 2018-05-29 11:27:23 --> Severity: Notice --> Undefined variable: val D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\views\form.php 130
ERROR - 2018-05-29 11:30:22 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 04:30:23 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:30:23 --> 404 Page Not Found: /index
ERROR - 2018-05-29 11:33:37 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 04:33:38 --> 404 Page Not Found: /index
ERROR - 2018-05-29 04:33:38 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:03:24 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:03:24 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:03:33 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 06:03:34 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:03:34 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:07:27 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:07:27 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:07:35 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 06:07:36 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:07:36 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:18:12 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 06:18:13 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:18:13 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:19:37 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 13:20:43 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 13:20:51 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 13:21:31 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 13:21:38 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 13:22:01 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 06:22:02 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:22:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:22:13 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 06:22:14 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:22:14 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:23:25 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\thamkhao\models\Thamkhao_model.php 198
ERROR - 2018-05-29 06:23:25 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:23:26 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:25:51 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:25:52 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:26:03 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:26:35 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:26:35 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:37:41 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-29 06:37:42 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:37:42 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:37:45 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:37:45 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:51:30 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 168
ERROR - 2018-05-29 06:51:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:51:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:51:49 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-29 13:51:49 --> Could not find the language line "last_name"
ERROR - 2018-05-29 13:51:49 --> Could not find the language line "groups"
ERROR - 2018-05-29 06:51:50 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:51:50 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:51:52 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:52:15 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:52:15 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:52:25 --> Could not find the language line "Menu Title"
ERROR - 2018-05-29 13:52:25 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-29 13:52:25 --> Could not find the language line "Menu Url"
ERROR - 2018-05-29 13:52:25 --> Could not find the language line "Menu Index"
ERROR - 2018-05-29 13:52:25 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-29 06:52:25 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:52:25 --> 404 Page Not Found: /index
ERROR - 2018-05-29 13:52:35 --> Could not find the language line "Menu Title"
ERROR - 2018-05-29 13:52:35 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-29 13:52:35 --> Could not find the language line "Menu Url"
ERROR - 2018-05-29 13:52:35 --> Could not find the language line "Menu Index"
ERROR - 2018-05-29 13:52:35 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-29 06:52:35 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:52:35 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:52:38 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:52:38 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:52:40 --> 404 Page Not Found: ../modules/hoachat/controllers/Chuangoc/chuangoc
ERROR - 2018-05-29 06:53:45 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:53:45 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:53:46 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:54:52 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:54:52 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:54:54 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:55:40 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:55:40 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:56:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:56:31 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:59:19 --> 404 Page Not Found: /index
ERROR - 2018-05-29 06:59:19 --> 404 Page Not Found: /index
ERROR - 2018-05-29 07:37:59 --> 404 Page Not Found: /index
ERROR - 2018-05-29 07:37:59 --> 404 Page Not Found: /index
ERROR - 2018-05-29 14:38:23 --> Could not find the language line "Menu Title"
ERROR - 2018-05-29 14:38:24 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-29 14:38:24 --> Could not find the language line "Menu Url"
ERROR - 2018-05-29 14:38:24 --> Could not find the language line "Menu Index"
ERROR - 2018-05-29 14:38:24 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-29 07:38:24 --> 404 Page Not Found: /index
ERROR - 2018-05-29 07:38:24 --> 404 Page Not Found: /index
ERROR - 2018-05-29 14:38:32 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-29 14:38:32 --> Could not find the language line "last_name"
ERROR - 2018-05-29 14:38:32 --> Could not find the language line "groups"
ERROR - 2018-05-29 07:38:32 --> 404 Page Not Found: /index
ERROR - 2018-05-29 07:38:32 --> 404 Page Not Found: /index
ERROR - 2018-05-29 14:38:41 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-29 14:38:41 --> Could not find the language line "last_name"
ERROR - 2018-05-29 14:38:41 --> Could not find the language line "groups"
ERROR - 2018-05-29 07:38:41 --> 404 Page Not Found: /index
ERROR - 2018-05-29 07:38:41 --> 404 Page Not Found: /index
ERROR - 2018-05-29 07:38:45 --> Severity: Notice --> Undefined variable: data D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 55
ERROR - 2018-05-29 07:38:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 55
ERROR - 2018-05-29 07:45:29 --> Severity: Notice --> Undefined variable: file_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 74
ERROR - 2018-05-29 07:46:05 --> Severity: Notice --> Undefined variable: file_name D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 74
ERROR - 2018-05-29 07:47:32 --> Severity: Notice --> Undefined variable: fileName D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 74
ERROR - 2018-05-29 07:48:01 --> Severity: Notice --> Undefined variable: fileName D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 74
ERROR - 2018-05-29 07:49:48 --> Severity: Parsing Error --> syntax error, unexpected '$write' (T_VARIABLE) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 74
ERROR - 2018-05-29 08:30:53 --> Severity: Notice --> Undefined variable: objPHPExcel D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 08:30:53 --> Severity: 4096 --> Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php on line 86 and defined D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\IOFactory.php 129
ERROR - 2018-05-29 08:30:53 --> Severity: error --> Exception: PHPExcel object unassigned. D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\Writer\Excel2007.php 400
ERROR - 2018-05-29 08:30:54 --> Severity: Notice --> Undefined variable: objPHPExcel D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 08:30:54 --> Severity: 4096 --> Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php on line 86 and defined D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\IOFactory.php 129
ERROR - 2018-05-29 08:30:54 --> Severity: error --> Exception: PHPExcel object unassigned. D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\Writer\Excel2007.php 400
ERROR - 2018-05-29 08:30:59 --> Severity: Notice --> Undefined variable: objPHPExcel D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 08:30:59 --> Severity: 4096 --> Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php on line 86 and defined D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\IOFactory.php 129
ERROR - 2018-05-29 08:30:59 --> Severity: error --> Exception: PHPExcel object unassigned. D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\Writer\Excel2007.php 400
ERROR - 2018-05-29 08:36:59 --> Severity: Notice --> Undefined variable: objPHPExcel D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 76
ERROR - 2018-05-29 08:36:59 --> Severity: 4096 --> Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php on line 76 and defined D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\IOFactory.php 129
ERROR - 2018-05-29 08:36:59 --> Severity: error --> Exception: PHPExcel object unassigned. D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\Writer\Excel2007.php 400
ERROR - 2018-05-29 08:37:01 --> Severity: Notice --> Undefined variable: objPHPExcel D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 76
ERROR - 2018-05-29 08:37:01 --> Severity: 4096 --> Argument 1 passed to PHPExcel_IOFactory::createWriter() must be an instance of PHPExcel, null given, called in D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php on line 76 and defined D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\IOFactory.php 129
ERROR - 2018-05-29 08:37:01 --> Severity: error --> Exception: PHPExcel object unassigned. D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\Writer\Excel2007.php 400
ERROR - 2018-05-29 08:40:41 --> Severity: Notice --> Undefined variable: objPHPExcel D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 32
ERROR - 2018-05-29 08:40:41 --> Severity: Error --> Call to a member function getProperties() on null D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 32
ERROR - 2018-05-29 08:44:50 --> Severity: Parsing Error --> syntax error, unexpected '$title' (T_VARIABLE) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 28
ERROR - 2018-05-29 08:45:38 --> Severity: Parsing Error --> syntax error, unexpected '$title' (T_VARIABLE) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 28
ERROR - 2018-05-29 08:46:00 --> Severity: Error --> Call to undefined function load() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 27
ERROR - 2018-05-29 08:46:08 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:46:08 --> Could not find the language line "menu_parent_id"
ERROR - 2018-05-29 08:46:34 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:46:34 --> Could not find the language line "menu_parent_id"
ERROR - 2018-05-29 08:46:38 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:46:38 --> Could not find the language line "menu_parent_id"
ERROR - 2018-05-29 08:46:46 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:46:46 --> Could not find the language line "menu_parent_id"
ERROR - 2018-05-29 08:47:11 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:49:57 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:50:18 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:52:45 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 80
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 81
ERROR - 2018-05-29 08:52:46 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 82
ERROR - 2018-05-29 08:52:56 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:53:07 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:53:21 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:21 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:22 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 08:53:33 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:53:52 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:54:08 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:58:03 --> Severity: Parsing Error --> syntax error, unexpected '++' (T_INC), expecting ')' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 49
ERROR - 2018-05-29 08:58:28 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:58:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:58:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:12 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:12 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:13 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:14 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:15 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:49 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:50 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:51 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 08:59:52 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:27 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:27 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:28 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:32 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:33 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:33 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:42 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:43 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:44 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:00:45 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:00:59 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:00:59 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:00 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:01 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 51
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:06 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:28 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:29 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:30 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:31 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:57 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:58 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:01:59 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:00 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:08 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:09 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:10 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 84
ERROR - 2018-05-29 09:02:11 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 85
ERROR - 2018-05-29 09:04:12 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:04:12 --> Severity: error --> Exception: Column string index can not be longer than 3 characters D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\Cell.php 824
ERROR - 2018-05-29 09:04:32 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:04:32 --> Severity: error --> Exception: Column string index can not be longer than 3 characters D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\Cell.php 824
ERROR - 2018-05-29 09:04:45 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:04:45 --> Severity: error --> Exception: Invalid cell coordinate G D:\HOST\www\bvtv\bvtv_app\third_party\PHPExcel\Cell.php 594
ERROR - 2018-05-29 09:05:01 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:01 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:02 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:03 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:04 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 86
ERROR - 2018-05-29 09:05:05 --> Severity: Notice --> Undefined variable: row D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 87
ERROR - 2018-05-29 09:07:24 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:07:38 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:10:41 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:11:44 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:14:08 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:08 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:09 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:10 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:11 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:12 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:13 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 2 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 3 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 4 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 5 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:14 --> Severity: Notice --> Uninitialized string offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Exceptions.php:271) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 105
ERROR - 2018-05-29 09:14:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Exceptions.php:271) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 106
ERROR - 2018-05-29 09:14:38 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:38 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:39 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:40 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:41 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:42 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:43 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:44 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:45 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:46 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:47 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:48 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:49 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:50 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:51 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:52 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Notice --> Uninitialized string offset: 0 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:53 --> Severity: Warning --> Illegal string offset 'menu_title' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:54 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:54 --> Severity: Warning --> Illegal string offset 'menu_url' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:54 --> Severity: Warning --> Illegal string offset 'menu_index' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:54 --> Severity: Warning --> Illegal string offset 'menu_icon' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:54 --> Severity: Warning --> Illegal string offset 'module_name' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 90
ERROR - 2018-05-29 09:14:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Exceptions.php:271) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 105
ERROR - 2018-05-29 09:14:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Exceptions.php:271) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 106
ERROR - 2018-05-29 09:14:57 --> Could not find the language line "menu_id"
ERROR - 2018-05-29 09:18:18 --> Severity: Notice --> Undefined offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 71
ERROR - 2018-05-29 09:19:04 --> Severity: Notice --> Undefined offset: 6 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 71
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:14 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:15 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Exceptions.php:271) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 88
ERROR - 2018-05-29 09:21:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Exceptions.php:271) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 89
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:33 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined offset: -1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Notice --> Undefined index:  D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 78
ERROR - 2018-05-29 09:21:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Exceptions.php:271) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 88
ERROR - 2018-05-29 09:21:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Exceptions.php:271) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 89
ERROR - 2018-05-29 09:22:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:22:09 --> 404 Page Not Found: /index
ERROR - 2018-05-29 09:37:26 --> Severity: Notice --> Undefined property: Test::$data D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 28
ERROR - 2018-05-29 09:38:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Common.php:196) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-29 09:38:05 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:41:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Common.php:196) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-29 09:41:50 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:43:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Common.php:196) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-29 09:43:02 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:44:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Common.php:196) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-29 09:44:10 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:46:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Common.php:196) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-29 09:46:47 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:46:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Common.php:196) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-29 09:46:59 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:47:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Common.php:196) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-29 09:47:11 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:48:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\HOST\www\bvtv\system_bvtv\core\Common.php:196) D:\HOST\www\bvtv\system_bvtv\core\Common.php 570
ERROR - 2018-05-29 09:48:12 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:49:42 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:50:07 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 09:51:13 --> Severity: Error --> Class 'CI_Ion_auth' not found D:\HOST\www\bvtv\system_bvtv\core\Common.php 196
ERROR - 2018-05-29 10:02:28 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php 34
ERROR - 2018-05-29 10:02:45 --> Severity: Parsing Error --> syntax error, unexpected 'include' (T_INCLUDE), expecting function (T_FUNCTION) D:\HOST\www\bvtv\bvtv_app\libraries\ExportExcel.php 22
ERROR - 2018-05-29 10:07:52 --> Severity: Warning --> Missing argument 3 for ExportExcel::create(), called in D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php on line 31 and defined D:\HOST\www\bvtv\bvtv_app\libraries\ExportExcel.php 24
ERROR - 2018-05-29 10:07:52 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\libraries\ExportExcel.php 49
ERROR - 2018-05-29 10:09:37 --> Severity: Warning --> Missing argument 3 for ExportExcel::create(), called in D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php on line 31 and defined D:\HOST\www\bvtv\bvtv_app\libraries\ExportExcel.php 24
ERROR - 2018-05-29 10:09:53 --> Severity: Warning --> Missing argument 3 for ExportExcel::create(), called in D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Test.php on line 31 and defined D:\HOST\www\bvtv\bvtv_app\libraries\ExportExcel.php 24
ERROR - 2018-05-29 10:13:45 --> 404 Page Not Found: /index
ERROR - 2018-05-29 10:13:45 --> 404 Page Not Found: /index
ERROR - 2018-05-29 17:13:49 --> Severity: Warning --> Missing argument 3 for ExportExcel::create(), called in D:\HOST\www\bvtv\bvtv_app\modules\hoachat\controllers\Chuangoc.php on line 687 and defined D:\HOST\www\bvtv\bvtv_app\libraries\ExportExcel.php 24
ERROR - 2018-05-29 17:20:04 --> Severity: Warning --> Missing argument 3 for ExportExcel::create(), called in D:\HOST\www\bvtv\bvtv_app\modules\hoachat\controllers\Chuangoc.php on line 687 and defined D:\HOST\www\bvtv\bvtv_app\libraries\ExportExcel.php 24
ERROR - 2018-05-29 10:26:22 --> 404 Page Not Found: /index
ERROR - 2018-05-29 10:26:22 --> 404 Page Not Found: /index
