<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-05-28 01:19:36 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 01:19:36 --> Could not find the language line "last_name"
ERROR - 2018-05-28 01:19:36 --> Could not find the language line "groups"
ERROR - 2018-05-28 01:19:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 01:19:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 01:34:02 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 01:34:02 --> Could not find the language line "last_name"
ERROR - 2018-05-28 01:34:02 --> Could not find the language line "groups"
ERROR - 2018-05-28 01:34:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 01:34:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 01:34:03 --> Severity: Notice --> Undefined variable: chuangoc D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 120
ERROR - 2018-05-28 01:52:44 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 01:52:44 --> Could not find the language line "last_name"
ERROR - 2018-05-28 01:52:44 --> Could not find the language line "groups"
ERROR - 2018-05-28 01:52:45 --> 404 Page Not Found: /index
ERROR - 2018-05-28 01:52:45 --> 404 Page Not Found: /index
ERROR - 2018-05-28 01:52:49 --> 404 Page Not Found: ../modules/hethong/controllers/Users/users
ERROR - 2018-05-28 01:53:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 01:53:28 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 01:53:28 --> Could not find the language line "last_name"
ERROR - 2018-05-28 01:53:28 --> Could not find the language line "groups"
ERROR - 2018-05-28 01:53:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 01:53:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:07:02 --> Severity: Warning --> explode() expects parameter 2 to be string, array given D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 166
ERROR - 2018-05-28 02:07:02 --> Query error: Column 'phanquyen' cannot be null - Invalid query: INSERT INTO `users` (`first_name`, `sinhnhat`, `phone`, `avatar`, `gioitinh`, `phanquyen`, `username`, `password`, `email`, `ip_address`, `created_on`, `active`) VALUES ('a', '28-05-2018', '1111111111', '', 'Nam', NULL, 'test', '$2y$08$eFdMdHtL0GLrk7fReDkDdOSki3f7kR5CmeDh77r80mYSwRH167xAq', 'aa@gmail.com', '::1', 1527473222, 1)
ERROR - 2018-05-28 02:08:04 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 02:08:04 --> Could not find the language line "last_name"
ERROR - 2018-05-28 02:08:04 --> Could not find the language line "groups"
ERROR - 2018-05-28 02:08:04 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:08:04 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:08:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:08:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:08:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:09:01 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:10:19 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:10:25 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:10:25 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:10:25 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:10:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:10:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:10:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 02:15:09 --> Severity: Parsing Error --> syntax error, unexpected 'var' (T_VAR) D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 1
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:15 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:21 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 02:25:21 --> Could not find the language line "last_name"
ERROR - 2018-05-28 02:25:21 --> Could not find the language line "groups"
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:25:23 --> Severity: Notice --> Undefined index: menu_id D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 164
ERROR - 2018-05-28 02:47:40 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 138
ERROR - 2018-05-28 02:49:48 --> Severity: Notice --> Undefined index: sub D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 107
ERROR - 2018-05-28 02:49:48 --> Severity: Notice --> Undefined index: sub D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 107
ERROR - 2018-05-28 02:49:48 --> Severity: Notice --> Undefined index: sub D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 107
ERROR - 2018-05-28 03:01:10 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:01:10 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:01:10 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:01:10 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:01:10 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:09:38 --> Severity: Notice --> Undefined offset: 10 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 171
ERROR - 2018-05-28 03:09:38 --> Severity: Notice --> Undefined offset: 10 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 171
ERROR - 2018-05-28 03:09:38 --> Severity: Notice --> Undefined offset: 10 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 171
ERROR - 2018-05-28 03:10:07 --> Severity: Notice --> Undefined offset: 10 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 171
ERROR - 2018-05-28 03:10:07 --> Severity: Notice --> Undefined offset: 10 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 171
ERROR - 2018-05-28 03:10:07 --> Severity: Notice --> Undefined offset: 10 D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 171
ERROR - 2018-05-28 03:17:44 --> Severity: Parsing Error --> syntax error, unexpected '{' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 165
ERROR - 2018-05-28 03:20:38 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:20:38 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:20:38 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:20:38 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:20:38 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:24:06 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:24:06 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:24:06 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:24:06 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:24:06 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:24:46 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 167
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:29:03 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:30:57 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:31:16 --> Severity: Warning --> Illegal string offset 'menu_parent_id' D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 163
ERROR - 2018-05-28 03:33:47 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:33:47 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:34:47 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:34:47 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:36:26 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 150
ERROR - 2018-05-28 03:36:26 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 150
ERROR - 2018-05-28 03:37:49 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 152
ERROR - 2018-05-28 03:37:49 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 152
ERROR - 2018-05-28 03:38:56 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 151
ERROR - 2018-05-28 03:38:56 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 151
ERROR - 2018-05-28 03:43:06 --> 404 Page Not Found: /index
ERROR - 2018-05-28 03:43:20 --> 404 Page Not Found: /index
ERROR - 2018-05-28 03:43:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 03:44:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 03:45:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 03:45:52 --> 404 Page Not Found: /index
ERROR - 2018-05-28 03:49:15 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 119
ERROR - 2018-05-28 03:49:15 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 119
ERROR - 2018-05-28 03:49:15 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 119
ERROR - 2018-05-28 03:49:15 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 119
ERROR - 2018-05-28 03:50:33 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 149
ERROR - 2018-05-28 03:50:39 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 121
ERROR - 2018-05-28 03:50:39 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 121
ERROR - 2018-05-28 03:50:39 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 121
ERROR - 2018-05-28 03:50:39 --> Severity: Notice --> Undefined index: menu_title D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 121
ERROR - 2018-05-28 03:51:58 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 150
ERROR - 2018-05-28 03:53:34 --> 404 Page Not Found: /index
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:23 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\create.php 122
ERROR - 2018-05-28 03:54:24 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:01:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:03:20 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 04:03:20 --> Could not find the language line "last_name"
ERROR - 2018-05-28 04:03:20 --> Could not find the language line "groups"
ERROR - 2018-05-28 04:03:20 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:03:20 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:03:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:03:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:03:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:03:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:10:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:10:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:10:54 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:11:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:14:07 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:17:52 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:20:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:22:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:23:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:23:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:24:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:25:55 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:26:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:26:45 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:27:35 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 04:27:35 --> Could not find the language line "last_name"
ERROR - 2018-05-28 04:27:35 --> Could not find the language line "groups"
ERROR - 2018-05-28 04:27:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:27:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:27:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:27:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 04:32:47 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 04:32:47 --> Could not find the language line "last_name"
ERROR - 2018-05-28 04:32:47 --> Could not find the language line "groups"
ERROR - 2018-05-28 04:32:52 --> Severity: Notice --> Undefined property: Users::$menu_model D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 277
ERROR - 2018-05-28 04:32:52 --> Severity: Error --> Call to a member function get_all() on null D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 277
ERROR - 2018-05-28 04:33:17 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 176
ERROR - 2018-05-28 06:11:19 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:11:19 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:11:19 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:11:19 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:11:19 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:16:34 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:16:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 297
ERROR - 2018-05-28 06:17:03 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:17:03 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 297
ERROR - 2018-05-28 06:17:32 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:18:46 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 303
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 296
ERROR - 2018-05-28 06:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 298
ERROR - 2018-05-28 06:22:12 --> Severity: Error --> Function name must be a string D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 100
ERROR - 2018-05-28 06:22:38 --> Severity: Notice --> Undefined variable: pq D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 100
ERROR - 2018-05-28 06:22:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 100
ERROR - 2018-05-28 06:22:38 --> Severity: Notice --> Undefined variable: pq D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 100
ERROR - 2018-05-28 06:22:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 100
ERROR - 2018-05-28 06:22:51 --> Severity: Notice --> Undefined index: id D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 100
ERROR - 2018-05-28 06:23:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:24:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:25:15 --> Severity: Notice --> Undefined variable: v1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 150
ERROR - 2018-05-28 06:25:15 --> Severity: Notice --> Undefined variable: v1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 156
ERROR - 2018-05-28 06:25:15 --> Severity: Notice --> Undefined variable: v1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 162
ERROR - 2018-05-28 06:25:15 --> Severity: Notice --> Undefined variable: v1 D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\user\edit.php 168
ERROR - 2018-05-28 06:29:54 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:29:54 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:29:54 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:29:54 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:29:54 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:30:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:30:59 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:30:59 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:30:59 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:31:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:31:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:38:39 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:38:39 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:38:39 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:38:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:38:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:39:11 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:39:11 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:39:11 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:39:11 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:39:11 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:40:08 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:40:08 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:40:08 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:40:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:40:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:40:37 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:40:37 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:40:37 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:40:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:40:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:41:01 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:41:01 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:41:01 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:41:01 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:41:01 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:41:27 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:41:27 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:41:27 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:41:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:41:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:50:06 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 310
ERROR - 2018-05-28 06:51:20 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:51:20 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:51:20 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:51:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:51:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:58:43 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 06:58:43 --> Could not find the language line "last_name"
ERROR - 2018-05-28 06:58:43 --> Could not find the language line "groups"
ERROR - 2018-05-28 06:58:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 06:58:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:00:07 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:00:08 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:00:08 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:00:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:00:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:08:37 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:08:37 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:08:37 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:08:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:08:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:08:58 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:08:58 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:08:58 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:08:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:08:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:09:05 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:09:25 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:09:25 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:09:25 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:09:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:09:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:09:36 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:09:40 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:09:42 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:10:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:11:03 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:11:03 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:11:03 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:11:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:11:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:11:20 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:11:29 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:11:29 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:11:29 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:11:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:11:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:11:49 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:11:49 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:11:49 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:11:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:11:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:12:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:15:37 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:15:38 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:15:38 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:15:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:15:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:15:59 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:15:59 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:15:59 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:15:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:15:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:16:45 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:16:45 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:16:45 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:16:45 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:16:45 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:17:16 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:17:16 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:17:16 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:17:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:17:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:17:31 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:17:31 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:17:31 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:17:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:17:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:18:00 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:18:00 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:18:00 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:18:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:18:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:18:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:18:17 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:19:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:19:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:20:09 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:20:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:20:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:20:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:20:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:20:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:20:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:46 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:21:47 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:21:47 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:21:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:54 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:54 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:21:55 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:22:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:22:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:22:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:22:45 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:22:46 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:22:46 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:24:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:25:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:25:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:25:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:25:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:25:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:25:55 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:25:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:25:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:27:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:27:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:27:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:28:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:28:09 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:28:09 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:28:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:28:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:28:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:33:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:33:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:33:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:33:55 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:33:55 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:33:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:34:02 --> 404 Page Not Found: ../modules/hoachat/controllers//index
ERROR - 2018-05-28 07:34:15 --> 404 Page Not Found: ../modules/hoachat/controllers//index
ERROR - 2018-05-28 07:34:25 --> 404 Page Not Found: ../modules/hoachat/controllers//index
ERROR - 2018-05-28 07:34:31 --> 404 Page Not Found: ../modules/hoachat/controllers//index
ERROR - 2018-05-28 07:34:34 --> 404 Page Not Found: ../modules/hoachat/controllers//index
ERROR - 2018-05-28 07:34:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:34:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:34:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:34:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:35:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:35:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:35:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:35:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:35:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:36:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:36:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:36:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:36:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:36:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:36:36 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:36:36 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:37:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:37:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:37:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:37:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:37:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:37:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:37:59 --> 404 Page Not Found: ../modules/hoachat/controllers//index
ERROR - 2018-05-28 07:38:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:38:24 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:38:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:38:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:38:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:38:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:38:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:38:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:38:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:42:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:42:18 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:42:19 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:42:19 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:42:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:42:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:42:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:45:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:45:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:45:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:45:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:45:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:45:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:15 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:15 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:46:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:48:32 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING), expecting function (T_FUNCTION) D:\HOST\www\bvtv\bvtv_app\modules\hoachat\controllers\Chuangoc.php 24
ERROR - 2018-05-28 07:48:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:48:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:48:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:09 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:09 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:34 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:34 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:40 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:49:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:50:36 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:50:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:50:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:50:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:50:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:50:42 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:52:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:52:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:52:17 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:52:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:52:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:52:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:53:06 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:53:06 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:53:06 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:53:06 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:53:06 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:53:35 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:53:35 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:53:35 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:53:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:53:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:53:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:12 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:54:12 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:54:12 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:54:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:32 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:32 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:54:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:55:01 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 07:55:01 --> Could not find the language line "last_name"
ERROR - 2018-05-28 07:55:01 --> Could not find the language line "groups"
ERROR - 2018-05-28 07:55:01 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:55:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:55:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:55:09 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:55:37 --> Could not find the language line "hcgoc_manufac"
ERROR - 2018-05-28 14:55:37 --> Could not find the language line "hcgoc_percent"
ERROR - 2018-05-28 07:55:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:55:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:55:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:55:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:56:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:56:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:56:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:56:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:56:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:56:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:56:36 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:56:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:57:02 --> Could not find the language line "hcgoc_manufac"
ERROR - 2018-05-28 14:57:02 --> Could not find the language line "hcgoc_percent"
ERROR - 2018-05-28 07:57:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:57:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:57:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:57:06 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:57:06 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:57:06 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:58:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:58:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:58:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:58:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:58:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 07:58:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:00:27 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:00:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:00:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:02:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:02:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:02:09 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:01 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:01 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:46 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:46 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:53 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:54 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:54 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:03:57 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:07:07 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:07:16 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:07:16 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:07:16 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:07:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:07:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:07:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:07:18 --> Severity: Warning --> implode(): Invalid arguments passed D:\HOST\www\bvtv\bvtv_app\modules\hethong\controllers\Users.php 177
ERROR - 2018-05-28 08:07:18 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:07:53 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:08:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:09:09 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:09:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:09:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:10:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:10:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:12:45 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:32:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:32:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:32:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:39:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:39:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:39:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:39:57 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 168
ERROR - 2018-05-28 08:39:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:05 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:07 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:07 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:08 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:17 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:18 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:18 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:24 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:33 --> Could not find the language line "Menu Title"
ERROR - 2018-05-28 08:40:33 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-28 08:40:33 --> Could not find the language line "Menu Url"
ERROR - 2018-05-28 08:40:33 --> Could not find the language line "Menu Index"
ERROR - 2018-05-28 08:40:33 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-28 08:40:33 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\models\Menu_model.php 200
ERROR - 2018-05-28 08:40:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:44 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:40:44 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:40:44 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:40:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:40:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:41:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:41:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:42:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:42:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:43:11 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:43:54 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:46:36 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:47:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:47:44 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:47:44 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:47:44 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:47:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:47:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:47:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:47:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:48:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:48:52 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:49:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:49:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:49:36 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:03 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:51:03 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:51:03 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:51:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:21 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:51:21 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:51:21 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:51:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:40 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:51:40 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:51:40 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:51:40 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:40 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:40 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:46 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:51:46 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:51:46 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:51:46 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:46 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:46 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:52 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:51:52 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:51:52 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:51:52 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:52 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:51:52 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:52:02 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:52:02 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:52:02 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:52:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:52:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:52:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:02 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:56:02 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:56:02 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:56:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:03 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:11 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:17 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:56:17 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:56:17 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:56:17 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:18 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:18 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:23 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:56:23 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:56:23 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:56:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:23 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:38 --> Could not find the language line "in_group"
ERROR - 2018-05-28 08:56:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:38 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:53 --> Could not find the language line "in_group"
ERROR - 2018-05-28 08:56:53 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:53 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:59 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 08:56:59 --> Could not find the language line "last_name"
ERROR - 2018-05-28 08:56:59 --> Could not find the language line "groups"
ERROR - 2018-05-28 08:56:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 08:56:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:23:50 --> Could not find the language line "in_group"
ERROR - 2018-05-28 09:23:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:28:24 --> Could not find the language line "in_group"
ERROR - 2018-05-28 09:28:24 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:28:27 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:28:28 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:28:28 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:28:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:28:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:28:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:29:30 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:29:30 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:29:30 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:29:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:29:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:29:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:30:12 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:30:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:31:40 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:31:46 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:31:49 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:31:49 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:31:49 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:31:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:31:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:32:21 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:32:21 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:32:21 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:32:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:32:21 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:33:34 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:33:34 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:33:34 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:33:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:33:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:33:42 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:33:42 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:33:42 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:33:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:33:43 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:33:51 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:33:51 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:33:51 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:33:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:33:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:40:47 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:40:47 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:40:47 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:40:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:40:47 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:40:50 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:41:56 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:41:57 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:41:58 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:41:58 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:41:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:41:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:42:21 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:42:22 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:42:22 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:42:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:42:22 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:42:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:48:59 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:49:25 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:49:25 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:49:25 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:49:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:49:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:49:31 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:49:31 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:49:31 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:49:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:49:31 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:51:13 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:51:13 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:51:13 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:51:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:51:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:51:20 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:51:25 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:51:25 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:51:25 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:51:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:51:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:51:28 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:51:31 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:51:31 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:51:31 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:51:32 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:51:32 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:51:34 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:52:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:52:16 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:52:16 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:52:16 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:52:16 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:52:17 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:52:19 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:52:48 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:52:48 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:52:48 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:52:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:52:49 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:54:16 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 16:54:17 --> Could not find the language line "last_name"
ERROR - 2018-05-28 16:54:17 --> Could not find the language line "groups"
ERROR - 2018-05-28 09:54:17 --> 404 Page Not Found: /index
ERROR - 2018-05-28 09:54:17 --> 404 Page Not Found: /index
ERROR - 2018-05-28 16:54:28 --> Could not find the language line "in_group"
ERROR - 2018-05-28 13:37:55 --> 404 Page Not Found: /index
ERROR - 2018-05-28 13:37:55 --> 404 Page Not Found: /index
ERROR - 2018-05-28 20:38:00 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 20:38:00 --> Could not find the language line "last_name"
ERROR - 2018-05-28 20:38:00 --> Could not find the language line "groups"
ERROR - 2018-05-28 13:38:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 13:38:00 --> 404 Page Not Found: /index
ERROR - 2018-05-28 13:56:14 --> 404 Page Not Found: /index
ERROR - 2018-05-28 20:56:51 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 168
ERROR - 2018-05-28 20:56:56 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 168
ERROR - 2018-05-28 20:57:04 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 20:57:04 --> Could not find the language line "last_name"
ERROR - 2018-05-28 20:57:04 --> Could not find the language line "groups"
ERROR - 2018-05-28 13:57:04 --> 404 Page Not Found: /index
ERROR - 2018-05-28 13:57:04 --> 404 Page Not Found: /index
ERROR - 2018-05-28 20:57:24 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 168
ERROR - 2018-05-28 20:57:38 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 20:57:38 --> Could not find the language line "last_name"
ERROR - 2018-05-28 20:57:38 --> Could not find the language line "groups"
ERROR - 2018-05-28 13:57:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 13:57:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 13:59:05 --> 404 Page Not Found: /index
ERROR - 2018-05-28 13:59:05 --> 404 Page Not Found: /index
ERROR - 2018-05-28 20:59:13 --> Severity: Notice --> Undefined offset: 0 D:\HOST\www\bvtv\bvtv_app\libraries\Menu.php 168
ERROR - 2018-05-28 13:59:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 13:59:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:00:34 --> Could not find the language line "Menu Title"
ERROR - 2018-05-28 21:00:34 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-28 21:00:34 --> Could not find the language line "Menu Url"
ERROR - 2018-05-28 21:00:34 --> Could not find the language line "Menu Index"
ERROR - 2018-05-28 21:00:34 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-28 21:00:34 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\models\Menu_model.php 155
ERROR - 2018-05-28 14:00:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:00:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:00:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:00:39 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:00:51 --> Could not find the language line "Menu Title"
ERROR - 2018-05-28 21:00:51 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-28 21:00:51 --> Could not find the language line "Menu Url"
ERROR - 2018-05-28 21:00:51 --> Could not find the language line "Menu Index"
ERROR - 2018-05-28 21:00:51 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-28 21:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\HOST\www\bvtv\bvtv_app\modules\hethong\models\Menu_model.php 200
ERROR - 2018-05-28 14:00:52 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:00:52 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:03:19 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:03:19 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:03:25 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 21:03:25 --> Could not find the language line "last_name"
ERROR - 2018-05-28 21:03:25 --> Could not find the language line "groups"
ERROR - 2018-05-28 14:03:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:03:26 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:03:35 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 21:03:35 --> Could not find the language line "last_name"
ERROR - 2018-05-28 21:03:35 --> Could not find the language line "groups"
ERROR - 2018-05-28 14:03:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:03:35 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:04:49 --> Severity: Notice --> Undefined variable: bvtv_donvis D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\donvi\view.php 20
ERROR - 2018-05-28 21:04:49 --> Severity: Notice --> Array to string conversion D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\donvi\view.php 56
ERROR - 2018-05-28 21:05:23 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-28 14:05:24 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:05:24 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:05:37 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:05:39 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-28 21:06:11 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-28 14:06:11 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:06:11 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:06:13 --> Severity: Notice --> Undefined variable: bvtv_donvi D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\donvi\form.php 24
ERROR - 2018-05-28 21:06:13 --> Severity: Notice --> Undefined variable: bvtv_donvi D:\HOST\www\bvtv\bvtv_app\modules\hethong\views\donvi\form.php 44
ERROR - 2018-05-28 14:06:33 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:10:11 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:10:53 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:11:23 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-28 14:11:24 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:11:24 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:11:32 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-28 14:11:32 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:11:32 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:11:44 --> Could not find the language line "head_title_donvi"
ERROR - 2018-05-28 14:11:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:11:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:18:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:18:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:18:28 --> Could not find the language line "Menu Title"
ERROR - 2018-05-28 21:18:28 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-28 21:18:28 --> Could not find the language line "Menu Url"
ERROR - 2018-05-28 21:18:28 --> Could not find the language line "Menu Index"
ERROR - 2018-05-28 21:18:28 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-28 14:18:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:18:29 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:18:40 --> Could not find the language line "Menu Title"
ERROR - 2018-05-28 21:18:40 --> Could not find the language line "Menu Parent"
ERROR - 2018-05-28 21:18:40 --> Could not find the language line "Menu Url"
ERROR - 2018-05-28 21:18:40 --> Could not find the language line "Menu Index"
ERROR - 2018-05-28 21:18:40 --> Could not find the language line "Menu Icon"
ERROR - 2018-05-28 14:18:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:18:41 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:18:47 --> Could not find the language line "head_title_groups"
ERROR - 2018-05-28 21:18:47 --> Could not find the language line "last_name"
ERROR - 2018-05-28 21:18:47 --> Could not find the language line "groups"
ERROR - 2018-05-28 14:18:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:18:48 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "head_title_thamkhao"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_name"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_sop"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_chidinh"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_phuongphap"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_hoaly"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_hoatchat"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_link"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_create"
ERROR - 2018-05-28 21:18:57 --> Could not find the language line "tk_user"
ERROR - 2018-05-28 21:18:58 --> Could not find the language line "tk_note"
ERROR - 2018-05-28 14:18:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:18:58 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_name"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_sop"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_chidinh"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_phuongphap"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_hoaly"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_hoatchat"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_link"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_create"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_user"
ERROR - 2018-05-28 21:19:29 --> Could not find the language line "tk_note"
ERROR - 2018-05-28 14:19:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:19:30 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_chidinh"
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_phuongphap"
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_hoaly"
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_hoatchat"
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_link"
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_create"
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_user"
ERROR - 2018-05-28 21:19:50 --> Could not find the language line "tk_note"
ERROR - 2018-05-28 14:19:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:19:51 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:20:43 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 14:20:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:20:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:22:43 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 14:22:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:22:44 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:23:12 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 14:23:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:23:13 --> 404 Page Not Found: /index
ERROR - 2018-05-28 21:23:17 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:23:27 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:23:28 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:24:50 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:24:51 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:24:51 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 21:25:02 --> Could not find the language line "tk_code"
ERROR - 2018-05-28 14:25:02 --> 404 Page Not Found: /index
ERROR - 2018-05-28 14:25:03 --> 404 Page Not Found: /index
