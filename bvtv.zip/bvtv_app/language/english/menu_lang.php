<?php
/**
 * @package	CodeIgniter
 * @author	MinhVan
 * @copyright   Copyright (c) 2018
 * @license http://opensource.org/licenses/MIT	MIT License
 * @since	Version 1.0.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');
$lang['head_title_sys_menu']		= 'Menu Hệ Thống';
$lang['menu_title']		= 'Tiêu đề menu';
$lang['menu_parent']	= 'Menu gốc';
$lang['menu_parent_id']	= 'Menu gốc';
$lang['menu_url']		= 'Đường dẫn';
$lang['menu_index']		= 'Vị trí';
$lang['menu_icon']		= 'Icon';
$lang['module_name']		= 'Tên module';
//$lang['menu_index']		= 'Tiêu đề';
//$lang['menu_index']		= 'Tiêu đề';
//$lang['menu_index']		= 'Tiêu đề';
//$lang['menu_index']		= 'Tiêu đề';