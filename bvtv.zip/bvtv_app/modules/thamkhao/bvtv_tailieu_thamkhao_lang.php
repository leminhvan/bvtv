<?php
/**
 * @created on : {datetime}
 * @author Le Minh Van
 * Copyright {year}
 */
defined('BASEPATH') OR exit('No direct script access allowed');
$lang['head_title_bvtv_tailieu_thamkhao']    = 'bvtv_tailieu_thamkhao';
  $lang['tk_code']    = 'tk_code';   $lang['tk_name']    = 'tk_name';   $lang['tk_sop']    = 'tk_sop';   $lang['tk_chidinh']    = 'tk_chidinh';   $lang['tk_phuongphap']    = 'tk_phuongphap';   $lang['tk_hoaly']    = 'tk_hoaly';   $lang['tk_hoatchat']    = 'tk_hoatchat';   $lang['tk_link']    = 'tk_link';   $lang['tk_create']    = 'tk_create';   $lang['tk_user']    = 'tk_user';   $lang['tk_note']    = 'tk_note'; 