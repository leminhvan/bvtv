<div>
	<a href="<?php echo base_url('hethong/test/save') ?>">Lưu file</a>
</div>