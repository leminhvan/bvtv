<?php
/**
 * @package	CodeIgniter
 * @author	domProjects Dev Team
 * @copyright   Copyright (c) 2015, domProjects, Inc. (http://domProjects.com/)
 * @license http://opensource.org/licenses/MIT	MIT License
 * @link    http://domProjects.com
 * @since	Version 1.0.0
 * @filesource
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['head_title_tk']	  = 'Tài liệu tham khảo';
$lang['Tk_Code']		  = 'Mã số';

$lang['Tk_Name']          = 'Tên';
$lang['Tk_Sop']           = 'SOP sử dụng';
$lang['Tk_Chidinh']       = 'Chỉ định';
$lang['Tk_Phuongphap']    = 'Phương pháp thử';
$lang['Tk_Hoaly']         = 'Phương pháp hóa lý';
$lang['Tk_Hoatchat']      = 'Hoạt chất';
$lang['Tk_Link']          = 'File';
$lang['Tk_Create']        = 'Ngày tạo';
$lang['Tk_User']          = 'Người tạo';
$lang['Tk_Note']          = 'Ghi chú';
