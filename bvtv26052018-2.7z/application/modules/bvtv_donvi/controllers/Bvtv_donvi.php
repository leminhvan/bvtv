<?php if (!defined('BASEPATH'))  exit('Không có quyền truy cập');

/**
 * Controller bvtv_donvi
 * @created on : Wednesday, 23-May-2018 04:16:40
 * @author Le Minh Van
 * Copyright 2018
 */

class Bvtv_donvi extends CI_Controller{
  
    public function __construct(){
        parent::__construct();         
        $this->load->model('bvtv_donvi_model');
        $this->load->library(array('form_validation'));
        $this->load->library('counter_visitor_online');
        $this->load->helper(array('form', 'url','notify_helper'));
        $this->lang->load('bvtv_donvi');

        if (!$this->ion_auth->logged_in() OR !$this->ion_auth->is_admin()) {
            redirect('login');
        }
        $this->counter_visitor_online->UsersOnline();
    }
    

    /**
    * lấy tất cả row bvtv_donvi
    *
    */
    public function index(){

        /*
        if (!$this->ion_auth->logged_in() OR !$this->ion_auth->is_admin()) {
            redirect(site_url('bvtv_donvi'));
        }*/

        $this->data['bvtv_donvis']   = $this->bvtv_donvi_model->get_all();
        $this->template->js_add("$('#select_all-menu').change(function() {
                                    var checkboxes = $(this).closest('table').find(':checkbox');
                                    checkboxes.prop('checked', $(this).is(':checked'));
                                }); " ,'embed');
        $this->template->js_add("function notify(message, type){
                                    $.growl({
                                        message: message
                                    },{
                                        type: type,
                                        allow_dismiss: false,
                                        label: 'Cancel',
                                        className: 'btn-xs btn-inverse',
                                        placement: {
                                            from: 'top',
                                            align: 'right'
                                        },
                                        delay: 2500,
                                        animate: {
                                                enter: 'animated bounceIn',
                                                exit: 'animated bounceOut'
                                        },
                                        offset: {
                                            x: 20,
                                            y: 85
                                        }
                                    });
                                };", "embed");
        $this->template->js_add('var csrfName = "'.$this->security->get_csrf_token_name().'";
                                var csrfHash = "'.$this->security->get_csrf_hash().'";
                                function ajax_action(id, action) {
                                    var data ={"id": id, "action": action}; data[csrfName] = csrfHash;
                                    var agrs = {
                                        url : "'.base_url().'bvtv_donvi/ajax_action", // gửi ajax đến file result.php
                                        type : "post", // chọn phương thức gửi là post
                                        dataType:"json", // dữ liệu trả về dạng text
                                        data : data,
                                        success : function (result){
                                            if(result.csrfName){ csrfName = result.csrfName; csrfHash = result.csrfHash;}
                                            if(result.data == 1 && result.action == "del"){
                                                $("#data_id_"+id).remove();
                                                swal({   
                                                    title: "Đã xóa!",   
                                                    timer: 2000,   
                                                    type: "success", 
                                                });   
                                            }
                                            if(result.data == 0 && result.action == "del"){
                                                swal("Lỗi", result.data, "error"); 
                                            }
                                            
                                            if(result.action == "detail"){
                                                var re = result.data; 
                                                var tempalte = "";
                                                $.each(re ,function(key, val){
                                                    if(key != "hcgoc_id" ){
                                                        tempalte += "<tr>";
                                                        tempalte +=      "<td width=\'120\' class=\'font-weight-bold\'>" + key + "</td>";
                                                        tempalte +=      "<td > " + val +"</td>";
                                                        tempalte += "</tr>";
                                                    }
                                                });
                                                $(".result").html(tempalte);
                                            }  
                                        }
                                    };
                                    // Truyền object vào để gọi ajax
                                    $.ajax(agrs);
                                }', "embed");
        $this->template->js_add('$(".xoa").click(function(){
                                        var id = $(this).attr("data-id");
                                        swal({   
                                            title: "Chắc chưa?",   
                                            text: "Không thể phục hồi đấy!",   
                                            type: "warning",   
                                            showCancelButton: true,   
                                            confirmButtonColor: "#DD6B55",   
                                            confirmButtonText: "Có, xóa nó đi",   
                                            cancelButtonText: "Không, có gì đó sai sai",   
                                            closeOnConfirm: false,   
                                            closeOnCancel: true, 
                                        }, function(isConfirm){
                                            if (isConfirm) { 
                                                ajax_action(id, "del");
                                            } 
                                        });
                                    });', "embed");
        $this->template->js_add('$(".detail").click(function(){
                                        var id = $(this).attr("data-id");
                                        $(".modal").attr("id", id);
                                        $(".result").html("<tr><td class=\'text-center\'><i class=\'md-rotate-right md-3x md-spin\' ></i></td></tr>");
                                        ajax_action(id, "detail");
                                    });', "embed");
        
        if($this->session->flashdata('notify') != NULL){
            $this->template->js_add("notify('".$this->session->flashdata('notify')['message']."');",'embed');
        }
        $this->template->load('index', 'view',$this->data);
    }

    

    /**
    * Tạo mới data cho bvtv_donvi
    *
    */
    public function add() {
        /*
        if (!$this->ion_auth->logged_in() OR !$this->ion_auth->is_admin()) {
            $this->session->set_flashdata('notify', notify('Không có quyền truy cập','warning'));
            redirect(site_url('bvtv_donvi'));
        }*/

        $this->data['bvtv_donvi']           = $this->bvtv_donvi_model->add();
        $this->data['action']            = 'bvtv_donvi/save';
        

        //them js va css
        // $this->template->js_add('','embed');    
      
        $this->template->load('index', 'form',$this->data);
    }

    /**
    * Sửa data cho bvtv_donvi
    *
    */
    public function edit($id='') {
         /*
        if (!$this->ion_auth->logged_in() OR !$this->ion_auth->is_admin()) {
            $this->session->set_flashdata('notify', notify('Không có quyền truy cập','warning'));
            redirect(site_url('bvtv_donvi'));
        }*/

        if ($id != ''){
            $this->data['bvtv_donvi']      = $this->bvtv_donvi_model->get_one($id);
            $this->data['action']       = 'bvtv_donvi/save/' . $id;           
           
                
            $this->template->load('index', 'form',$this->data);
        } else{
            $this->session->set_flashdata('notify', notify('Không thấy data','info'));
            redirect(site_url('bvtv_donvi'));
        }
    }
    
    /**
    * Cập nhật database  bvtv_donvi
    *
    */
    public function save($id =NULL){
          /*
        if (!$this->ion_auth->logged_in() OR !$this->ion_auth->is_admin()) {
            $this->session->set_flashdata('notify', notify('Không có quyền truy cập','warning'));
            redirect(site_url('bvtv_donvi'));
        }*/

        // validation config
        $config = array(
                  
                    array(
                        'field' => 'donvi_kyhieu',
                        'label' => lang('donvi_kyhieu'),
                        'rules' => 'trim|required'
                        ),
                    
                    array(
                        'field' => 'donvi_mota',
                        'label' => lang('donvi_mota'),
                        'rules' => 'trim'
                        ),
                               
                  );
            
        // if id NULL then add new data
        if(!$id) {    
                  $this->form_validation->set_rules($config);
                  $this->form_validation->set_error_delimiters('<small class="form-text text-muted red-text">', '</small>');
                  if ($this->form_validation->run() == TRUE) {
                      if ($this->input->post()) {
                          $this->bvtv_donvi_model->save();
                          $this->session->set_flashdata('notify', notify('Thêm thành công','success'));
                          redirect('bvtv_donvi');
                      }
                  }else{ // If validation incorrect 
                      $this->add();
                  }
         }
         else{ // Update data if Form Edit send Post and ID available
                $this->form_validation->set_rules($config);
                $this->form_validation->set_error_delimiters('<small class="form-text text-muted red-text">', '</small>');
                if ($this->form_validation->run() == TRUE)  {
                    if ($this->input->post())  {
                        $this->bvtv_donvi_model->update($id);
                        $this->session->set_flashdata('notify', notify('Update thành công','success'));
                        redirect('bvtv_donvi');
                    }
                } else{ // If validation incorrect 
                    $this->edit($id);
                }
         }
    }
    
    /**
    * Xóa bvtv_donvi by ID
    *
    */

    public function ajax_action(){   
        $id = strip_tags($this->input->post('id', TRUE));
        $action = strip_tags($this->input->post('action', TRUE));
        $output = new stdClass;
        $output->csrfName = $this->security->get_csrf_token_name();
        $output->csrfHash = $this->security->get_csrf_hash();
        $output->data = 0; $output->action = "";

        if ($this->ion_auth->logged_in() AND $this->ion_auth->is_admin()) {//co the thay doi quyen
           // ID phải lớn hơn 0
            if ($id>=0 AND $action == "del") {
                $this->bvtv_donvi_model->destroy($id);   $output->data = 1; $output->action = $action;       
            }
            if ($id>=0 AND $action == "detail") {
                $output->data = $this->bvtv_donvi_model->get_one($id); $output->action = $action;       
            }

        }
        echo json_encode($output);
    }
}
?>