<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <?php echo lang('head_title_hcgoc'); ?>
    </h1>
  
</section>

<section class="content">

  <!--In thong bao cho action -->
  <?php 
      echo $this->session->flashdata('notify');
  ?>
  <!-- start box-->
    <div class="box">
      <div class="box-header with-border">
              <h3 class="box-title"><?php if(strpos(current_url(), 'add')) {echo lang('box_title_create');} else{echo lang('box_title_edit');}  ?></h3>

              <div class="box-tools pull-right">
                  <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                      <i class="fa fa-minus"></i></button>
                  <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                      <i class="fa fa-times"></i></button>
              </div>
          </div>

  <div class="box-body">

    <?php echo form_open(site_url('bvtv_tailieu_thamkhao/' . $action),'role="form" class="form-horizontal" id="form_bvtv_tailieu_thamkhao" parsley-validate'); ?>               
 
             
                           
                   <div class="form-group">
                       <label for="tk_code" class="col-sm-2 control-label">Tk Code <span class="required-input">*</span></label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_code',
                                 'id'           => 'tk_code',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Tk Code',
                                 'maxlength'=>'45'
                                 ),
                                 set_value('tk_code',$bvtv_tailieu_thamkhao['tk_code'])
                           );             
                      ?>
                     <?php echo form_error('tk_code');?>
                    </div>
                  </div> <!--/ Tk Code -->
                              
                   <div class="form-group">
                       <label for="tk_name" class="col-sm-2 control-label">Tk Name</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_textarea(
                            array(
                                'id'            =>'tk_name',
                                'name'          =>'tk_name',
                                'rows'          =>'3',
                                'class'         =>'form-control input-sm ',
                                'placeholder'   =>'Tk Name',
                                'maxlength'=>'255'
                                ),
                            set_value('tk_name',$bvtv_tailieu_thamkhao['tk_name'])                           
                            );             
                      ?>
                     <?php echo form_error('tk_name');?>
                    </div>
                  </div> <!--/ Tk Name -->
                              
                   <div class="form-group">
                       <label for="tk_sop" class="col-sm-2 control-label">Tk Sop</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_sop',
                                 'id'           => 'tk_sop',                       
                                 'class'        => 'form-control input-sm ',
                                 'placeholder'  => 'Tk Sop',
                                 'maxlength'=>'45'
                                 ),
                                 set_value('tk_sop',$bvtv_tailieu_thamkhao['tk_sop'])
                           );             
                      ?>
                     <?php echo form_error('tk_sop');?>
                    </div>
                  </div> <!--/ Tk Sop -->
                              
                   <div class="form-group">
                       <label for="tk_chidinh" class="col-sm-2 control-label">Tk Chidinh</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_checkbox(
                            array(
                                 'name'  => 'tk_chidinh',
                                 'id'    => 'tk_chidinh',                       
                                 'class' => 'form-control input-sm ',                                 
                                 )
                            )             
                      ?>
                     <?php echo form_error('tk_chidinh');?>
                    </div>
                  </div> <!--/ Tk Chidinh -->
                              
                   <div class="form-group">
                       <label for="tk_phuongphap" class="col-sm-2 control-label">Tk Phuongphap</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_phuongphap',
                                 'id'           => 'tk_phuongphap',                       
                                 'class'        => 'form-control input-sm ',
                                 'placeholder'  => 'Tk Phuongphap',
                                 'maxlength'=>'45'
                                 ),
                                 set_value('tk_phuongphap',$bvtv_tailieu_thamkhao['tk_phuongphap'])
                           );             
                      ?>
                     <?php echo form_error('tk_phuongphap');?>
                    </div>
                  </div> <!--/ Tk Phuongphap -->
                              
                   <div class="form-group">
                       <label for="tk_hoaly" class="col-sm-2 control-label">Tk Hoaly</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_hoaly',
                                 'id'           => 'tk_hoaly',                       
                                 'class'        => 'form-control input-sm ',
                                 'placeholder'  => 'Tk Hoaly',
                                 'maxlength'=>'45'
                                 ),
                                 set_value('tk_hoaly',$bvtv_tailieu_thamkhao['tk_hoaly'])
                           );             
                      ?>
                     <?php echo form_error('tk_hoaly');?>
                    </div>
                  </div> <!--/ Tk Hoaly -->
                              
                   <div class="form-group">
                       <label for="tk_hoatchat" class="col-sm-2 control-label">Tk Hoatchat</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_hoatchat',
                                 'id'           => 'tk_hoatchat',                       
                                 'class'        => 'form-control input-sm ',
                                 'placeholder'  => 'Tk Hoatchat',
                                 'maxlength'=>'45'
                                 ),
                                 set_value('tk_hoatchat',$bvtv_tailieu_thamkhao['tk_hoatchat'])
                           );             
                      ?>
                     <?php echo form_error('tk_hoatchat');?>
                    </div>
                  </div> <!--/ Tk Hoatchat -->
                              
                   <div class="form-group">
                       <label for="tk_link" class="col-sm-2 control-label">Tk Link <span class="required-input">*</span></label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_link',
                                 'id'           => 'tk_link',                       
                                 'class'        => 'form-control input-sm  required',
                                 'placeholder'  => 'Tk Link',
                                 'maxlength'=>'45'
                                 ),
                                 set_value('tk_link',$bvtv_tailieu_thamkhao['tk_link'])
                           );             
                      ?>
                     <?php echo form_error('tk_link');?>
                    </div>
                  </div> <!--/ Tk Link -->
                              
                   <div class="form-group">
                       <label for="tk_create" class="col-sm-2 control-label">Tk Create</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_create',
                                 'id'           => 'tk_create',                       
                                 'class'        => 'form-control input-sm ',
                                 'placeholder'  => 'Tk Create',
                                 
                                 ),
                                 set_value('tk_create',$bvtv_tailieu_thamkhao['tk_create'])
                           );             
                      ?>
                     <?php echo form_error('tk_create');?>
                    </div>
                  </div> <!--/ Tk Create -->
                              
                   <div class="form-group">
                       <label for="tk_user" class="col-sm-2 control-label">Tk User</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_user',
                                 'id'           => 'tk_user',                       
                                 'class'        => 'form-control input-sm ',
                                 'placeholder'  => 'Tk User',
                                 'maxlength'=>'45'
                                 ),
                                 set_value('tk_user',$bvtv_tailieu_thamkhao['tk_user'])
                           );             
                      ?>
                     <?php echo form_error('tk_user');?>
                    </div>
                  </div> <!--/ Tk User -->
                              
                   <div class="form-group">
                       <label for="tk_note" class="col-sm-2 control-label">Tk Note</label>
                    <div class="col-sm-6">                                   
                      <?php                  
                       echo form_input(
                                array(
                                 'name'         => 'tk_note',
                                 'id'           => 'tk_note',                       
                                 'class'        => 'form-control input-sm ',
                                 'placeholder'  => 'Tk Note',
                                 'maxlength'=>'45'
                                 ),
                                 set_value('tk_note',$bvtv_tailieu_thamkhao['tk_note'])
                           );             
                      ?>
                     <?php echo form_error('tk_note');?>
                    </div>
                  </div> <!--/ Tk Note -->
                   
               
              <div class="row"> 
                  <!-- <div class="col-md-10 col-sm-12 col-md-offset-2 col-sm-offset-0"> -->
                  <div class="col-md-12 col-sm-12 col-lg-12 text-right">

                       <a href="<?php echo site_url('bvtv_tailieu_thamkhao'); ?>" class="btn btn-default">
                           <i class="glyphicon glyphicon-chevron-left"></i> <?php echo lang('actions_back'); ?>
                       </a> 
                        <button type="submit" class="btn btn-primary" name="post">
                            <i class="glyphicon glyphicon-floppy-save"></i> <?php echo lang('actions_save'); ?>
                        </button>                  
                  </div>
              </div>
    <?php echo form_close(); ?>  

    </div><!--end box body -->
  </div><!--end box -->
</section>