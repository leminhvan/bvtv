<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <?php echo lang('head_title_tk'); ?>
    </h1>
</section>



<section class="content">

  <!--In thong bao cho action -->
  <?php 
      echo $this->session->flashdata('notify');
  ?>
  <!-- start box-->
    <div class="box">
      <div class="box-header with-border">
              <h3 class="box-title"><?php echo lang('box_title_list'); ?> </h3>

              <div class="box-tools pull-right">
                  <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                      <i class="fa fa-minus"></i></button>
                  <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                      <i class="fa fa-times"></i></button>
              </div>
          </div>

  <div class="box-body">
      <?php if ($bvtv_tailieu_thamkhaos) : ?>
          <table id="tabledata" class="display compact" role="grid" aria-describedby="dynamic-table_info">
              
            <thead>
              <tr>
                <th>STT</th>

                  <th><?php echo lang('Tk_Hoatchat'); ?></th>   
                    <th><?php echo lang('Tk_Code'); ?></th>   
                
                    <th><?php echo lang('Tk_Name'); ?></th>   
                
                    <th><?php echo lang('Tk_Sop'); ?></th>   
                
                    <th><?php echo lang('Tk_Chidinh'); ?></th>   
                
                    <th><?php echo lang('Tk_Phuongphap'); ?></th>   
                
                    <th><?php echo lang('Tk_Hoaly'); ?></th>   
                
                    <th><?php echo lang('Tk_Link'); ?></th>   
                                
                    <th><?php echo lang('Tk_Note'); ?></th>   
                
                <th align="right" width="50">Actions</th>
              </tr>
            </thead>
            
            
            <tbody>
             
               <?php foreach ($bvtv_tailieu_thamkhaos as $bvtv_tailieu_thamkhao) : ?>
              <tr>
                <td></td>
                <td><?php echo $bvtv_tailieu_thamkhao['tk_hoatchat']; ?></td>
               <td><?php echo $bvtv_tailieu_thamkhao['tk_code']; ?></td>
               
               <td width="220"><?php echo $bvtv_tailieu_thamkhao['tk_name']; ?></td>
               
               <td><?php echo $bvtv_tailieu_thamkhao['tk_sop']; ?></td>
               
               <td><?php echo $bvtv_tailieu_thamkhao['tk_chidinh']; ?></td>
               
               <td><?php echo $bvtv_tailieu_thamkhao['tk_phuongphap']; ?></td>
               
               <td><?php echo $bvtv_tailieu_thamkhao['tk_hoaly']; ?></td>
               
               <td><?php
               $link = base64_encode(base_url().'uploads/files/tltk/'.$bvtv_tailieu_thamkhao['tk_link'].'.pdf');
               //$bang = substr_count($link, '=') ;
               $remove = str_replace('=','', $link);

               
               echo anchor(
                  site_url('bvtv_tailieu_thamkhao/viewFile/' . $remove),
                    '<i class="fas fa-file-pdf fa-2x"></i>',
                    'data-tooltip="tooltip" data-placement="top" title="Xem" target="_blank"'
                  ); 
                  ?>
                </td>
                              
               <td><?php echo $bvtv_tailieu_thamkhao['tk_note']; ?></td>
               <?php
                                  
                   ?>
                <td nowrap>    
                    
                    <?php
                                  echo anchor(
                                          site_url('bvtv_tailieu_thamkhao/show/' . $bvtv_tailieu_thamkhao['tk_id']),
                                            '<i class="fas fa-info-circle"></i>',
                                            'class="btn btn-xs btn-info" data-tooltip="tooltip" data-placement="top" title="Chi tiết"'
                                          );
                   ?>
                    
                    <?php
                                  echo anchor(
                                          site_url('bvtv_tailieu_thamkhao/edit/' . $bvtv_tailieu_thamkhao['tk_id']),
                                            '<i class="fas fa-edit"></i>',
                                            'class="btn btn-xs btn-success" data-tooltip="tooltip" data-placement="top" title="Sửa"'
                                          );
                   ?>
                   
                   <?php
                                  echo anchor(
                                          site_url('bvtv_tailieu_thamkhao/destroy/' . $bvtv_tailieu_thamkhao['tk_id']),
                                            '<i class="far fa-trash-alt"></i>',
                                            'onclick="return confirm(\'Xóa dòng này?\');" class="btn btn-xs btn-danger" data-tooltip="tooltip" data-placement="top" title="Xóa"'
                                          );
                   ?>   
                                 
                </td>
              </tr>     
               <?php endforeach; ?>
            </tbody>
          </table>
          <?php else: ?>
                <?php  echo notify('Không có data','info');?>
          <?php endif; ?>

          <!--nut them -->
            <p>                
                <?php
                      echo anchor(
                               site_url('bvtv_tailieu_thamkhao/add'),
                                '<i class="glyphicon glyphicon-plus"></i>'.lang('actions_add'),
                                'class="btn btn-success btn-sm" data-tooltip="tooltip" data-placement="top" title="'.lang('actions_add').'"'
                              );
                ?>
            <p>
    </div><!--end box body -->
  </div><!--end box -->
</section>