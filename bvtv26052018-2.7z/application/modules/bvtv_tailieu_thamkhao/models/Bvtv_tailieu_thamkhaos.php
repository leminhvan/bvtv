<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of bvtv_tailieu_thamkhao
 * @created on : {tanggal}
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2018    
 */
 
 
class Bvtv_tailieu_thamkhaos extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data bvtv_tailieu_thamkhao
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all() 
    {
        //$result = $this->db->query("SELECT * FROM bvtv_tailieu_thamkhao ORDER BY tk_hoatchat DESC");
        $result = $this->db->query("SELECT * FROM bvtv_tailieu_thamkhao");
        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }
    
    
    /**
    *  Get One bvtv_tailieu_thamkhao
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('tk_id', $id);
        $result = $this->db->get('bvtv_tailieu_thamkhao');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data bvtv_tailieu_thamkhao
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'tk_code' => '',
            
                'tk_name' => '',
            
                'tk_sop' => '',
            
                'tk_chidinh' => '',
            
                'tk_phuongphap' => '',
            
                'tk_hoaly' => '',
            
                'tk_hoatchat' => '',
            
                'tk_link' => '',
            
                'tk_create' => '',
            
                'tk_user' => '',
            
                'tk_note' => '',
            
        );

        return $data;
    }

    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {
        $data = array(
        
            'tk_code' => strip_tags($this->input->post('tk_code', TRUE)),
        
            'tk_name' => strip_tags($this->input->post('tk_name', TRUE)),
        
            'tk_sop' => strip_tags($this->input->post('tk_sop', TRUE)),
        
            'tk_chidinh' => strip_tags($this->input->post('tk_chidinh', TRUE)),
        
            'tk_phuongphap' => strip_tags($this->input->post('tk_phuongphap', TRUE)),
        
            'tk_hoaly' => strip_tags($this->input->post('tk_hoaly', TRUE)),
        
            'tk_hoatchat' => strip_tags($this->input->post('tk_hoatchat', TRUE)),
        
            'tk_link' => strip_tags($this->input->post('tk_link', TRUE)),
        
            'tk_create' => strip_tags($this->input->post('tk_create', TRUE)),
        
            'tk_user' => strip_tags($this->input->post('tk_user', TRUE)),
        
            'tk_note' => strip_tags($this->input->post('tk_note', TRUE)),
        
        );
        
        
        $this->db->insert('bvtv_tailieu_thamkhao', $data);
    }
    
    
    

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'tk_code' => strip_tags($this->input->post('tk_code', TRUE)),
        
                'tk_name' => strip_tags($this->input->post('tk_name', TRUE)),
        
                'tk_sop' => strip_tags($this->input->post('tk_sop', TRUE)),
        
                'tk_chidinh' => strip_tags($this->input->post('tk_chidinh', TRUE)),
        
                'tk_phuongphap' => strip_tags($this->input->post('tk_phuongphap', TRUE)),
        
                'tk_hoaly' => strip_tags($this->input->post('tk_hoaly', TRUE)),
        
                'tk_hoatchat' => strip_tags($this->input->post('tk_hoatchat', TRUE)),
        
                'tk_link' => strip_tags($this->input->post('tk_link', TRUE)),
        
                'tk_create' => strip_tags($this->input->post('tk_create', TRUE)),
        
                'tk_user' => strip_tags($this->input->post('tk_user', TRUE)),
        
                'tk_note' => strip_tags($this->input->post('tk_note', TRUE)),
        
        );
        
        
        $this->db->where('tk_id', $id);
        $this->db->update('bvtv_tailieu_thamkhao', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('tk_id', $id);
        $this->db->delete('bvtv_tailieu_thamkhao');
        
    }




 public function update_hc($id, $hc)
    {
        $data = array(
        
                'tk_code' => $hc
        
               
        );
        
        
        $this->db->where('tk_id', $id);
        $this->db->update('bvtv_tailieu_thamkhao', $data);
    }


    



}
