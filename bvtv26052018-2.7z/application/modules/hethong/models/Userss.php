<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Description of users
 * @created on : {tanggal}
 * @author DAUD D. SIMBOLON <daud.simbolon@gmail.com>
 * Copyright 2018    
 */
 
 
class Userss extends CI_Model 
{

    public function __construct() 
    {
        parent::__construct();
    }


    /**
     *  Get All data users
     *
     *  @param limit  : Integer
     *  @param offset : Integer
     *
     *  @return array
     *
     */
    public function get_all() 
    {

        $result = $this->db->get('users');

        if ($result->num_rows() > 0) 
        {
            return $result->result_array();
        } 
        else 
        {
            return array();
        }
    }
    
    
    /**
    *  Get One users
    *
    *  @param id : Integer
    *
    *  @return array
    *
    */
    public function get_one($id) 
    {
        $this->db->where('id', $id);
        $result = $this->db->get('users');

        if ($result->num_rows() == 1) 
        {
            return $result->row_array();
        } 
        else 
        {
            return array();
        }
    }

    
    
    
    /**
    *  Default form data users
    *  @return array
    *
    */
    public function add()
    {
        $data = array(
            
                'ip_address' => '',
            
                'username' => '',
            
                'password' => '',
            
                'salt' => '',
            
                'email' => '',
            
                'activation_code' => '',
            
                'forgotten_password_code' => '',
            
                'forgotten_password_time' => '',
            
                'remember_code' => '',
            
                'created_on' => '',
            
                'last_login' => '',
            
                'active' => '',
            
                'first_name' => '',
            
                'gioitinh' => '',
            
                'sinhnhat' => '',
            
                'phone' => '',
            
        );

        return $data;
    }

    
    
    /**
    *  Save data Post
    *
    *  @return void
    *
    */
    public function save() 
    {
        $data = array(
        
            'ip_address' => strip_tags($this->input->post('ip_address', TRUE)),
        
            'username' => strip_tags($this->input->post('username', TRUE)),
        
            'password' => strip_tags($this->input->post('password', TRUE)),
        
            'salt' => strip_tags($this->input->post('salt', TRUE)),
        
            'email' => strip_tags($this->input->post('email', TRUE)),
        
            'activation_code' => strip_tags($this->input->post('activation_code', TRUE)),
        
            'forgotten_password_code' => strip_tags($this->input->post('forgotten_password_code', TRUE)),
        
            'forgotten_password_time' => strip_tags($this->input->post('forgotten_password_time', TRUE)),
        
            'remember_code' => strip_tags($this->input->post('remember_code', TRUE)),
        
            'created_on' => strip_tags($this->input->post('created_on', TRUE)),
        
            'last_login' => strip_tags($this->input->post('last_login', TRUE)),
        
            'active' => strip_tags($this->input->post('active', TRUE)),
        
            'first_name' => strip_tags($this->input->post('first_name', TRUE)),
        
            'gioitinh' => strip_tags($this->input->post('gioitinh', TRUE)),
        
            'sinhnhat' => strip_tags($this->input->post('sinhnhat', TRUE)),
        
            'phone' => strip_tags($this->input->post('phone', TRUE)),
        
        );
        
        
        $this->db->insert('users', $data);
    }
    
    
    

    
    /**
    *  Update modify data
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function update($id)
    {
        $data = array(
        
                'ip_address' => strip_tags($this->input->post('ip_address', TRUE)),
        
                'username' => strip_tags($this->input->post('username', TRUE)),
        
                'password' => strip_tags($this->input->post('password', TRUE)),
        
                'salt' => strip_tags($this->input->post('salt', TRUE)),
        
                'email' => strip_tags($this->input->post('email', TRUE)),
        
                'activation_code' => strip_tags($this->input->post('activation_code', TRUE)),
        
                'forgotten_password_code' => strip_tags($this->input->post('forgotten_password_code', TRUE)),
        
                'forgotten_password_time' => strip_tags($this->input->post('forgotten_password_time', TRUE)),
        
                'remember_code' => strip_tags($this->input->post('remember_code', TRUE)),
        
                'created_on' => strip_tags($this->input->post('created_on', TRUE)),
        
                'last_login' => strip_tags($this->input->post('last_login', TRUE)),
        
                'active' => strip_tags($this->input->post('active', TRUE)),
        
                'first_name' => strip_tags($this->input->post('first_name', TRUE)),
        
                'gioitinh' => strip_tags($this->input->post('gioitinh', TRUE)),
        
                'sinhnhat' => strip_tags($this->input->post('sinhnhat', TRUE)),
        
                'phone' => strip_tags($this->input->post('phone', TRUE)),
        
        );
        
        
        $this->db->where('id', $id);
        $this->db->update('users', $data);
    }


    
    
    
    /**
    *  Delete data by id
    *
    *  @param id : Integer
    *
    *  @return void
    *
    */
    public function destroy($id)
    {       
        $this->db->where('id', $id);
        $this->db->delete('users');
        
    }







    



}
