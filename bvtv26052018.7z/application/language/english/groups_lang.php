<?php
/**
 * @package CodeIgniter
 * @author  MinhVan
 * @copyright   Copyright (c) 2018
 * @license http://opensource.org/licenses/MIT  MIT License
 * @since Version 1.0.0
 */
defined('BASEPATH') OR exit('No direct script access allowed');
$lang['head_title_groups']    = 'groups';
  $lang['name']    = 'Tên nhóm';
  $lang['description']    = 'Mô tả';
  $lang['bgcolor']    = 'Màu nền';
