<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <?php echo lang('head_title_hcgoc'); ?>
    </h1>
</section>

<section class="content">

  <!--In thong bao cho action -->
  <?php 
      echo $this->session->flashdata('notify');
  ?>
  <!-- start box-->
    <div class="box">
      <div class="box-header with-border">
              <h3 class="box-title"><?php echo lang('box_title_show'); ?></h3>

              <div class="box-tools pull-right">
                  <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                      <i class="fa fa-minus"></i></button>
                  <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                      <i class="fa fa-times"></i></button>
              </div>
          </div>

  <div class="box-body">

        <?php 
            if($bvtv_tailieu_thamkhao) :
        ?> 

        <div class="table-responsive">
            <table id="detail" class="table table-striped table-condensed">
                <tbody>
                <?php     
                    foreach($bvtv_tailieu_thamkhao as $table => $value) :    
                ?>
                <tr>
                    <td width="20%" align="right"><strong><?php echo ucwords(str_replace("_"," ","$table")); ?></strong></td>
                    <td><?php echo $value ?></td>
                </tr>
                 <?php 
                    endforeach;
                 ?>
                 </tbody>
            </table>
        </div>


        	<?php 
        	
        		echo anchor(site_url('bvtv_tailieu_thamkhao'), '<span class="fa fa-chevron-left"></span>'.lang('actions_back'), 'class="btn btn-sm btn-default"');
        	
        	?>


        <br /><br />

        <?php 
            endif;
        ?>

    </div><!--end box body -->
  </div><!--end box -->
</section>