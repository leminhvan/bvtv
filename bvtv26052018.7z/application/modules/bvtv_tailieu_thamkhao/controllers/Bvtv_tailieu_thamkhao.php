<?php if (!defined('BASEPATH'))  exit('No direct script access allowed');

/**
 * Controller bvtv_tailieu_thamkhao
 * @created on : Thursday, 08-Feb-2018 07:19:08
 * @author Le Minh Van
 * Copyright 2018
 */

class Bvtv_tailieu_thamkhao extends CI_Controller
{

    public function __construct() 
    {
        parent::__construct();         
        $this->load->model('bvtv_tailieu_thamkhaos');
        $this->load->library(array('form_validation'));
        $this->load->helper(array('form', 'url', 'notify_helper'));
        $this->lang->load('bvtv_tailieu_thamkhao');
    }
    

    /**
    * List all data bvtv_tailieu_thamkhao
    *
    */
    public function index() 
    {
        $this->data['bvtv_tailieu_thamkhaos'] = array();
        $temp   = $this->bvtv_tailieu_thamkhaos->get_all();
        $count_sop = 0;
        $count_chidinh = 0;
        foreach ($temp  as $key => $value) {
            if($value['tk_chidinh'] ==1 ){
                $count_chidinh ++;
                $value['tk_chidinh'] = ' <span class = "label label-success"> Chỉ định</span>';
            }else{
                $value['tk_chidinh'] = '';
            }

            if($value['tk_sop'] != ''){
                $count_sop ++;
            }
            array_push($this->data['bvtv_tailieu_thamkhaos'], $value);
        }

        if($count_sop > 0){
            $this->data['taskboard'][] = array('name' => 'Chỉ định/SOP', 'message' => $count_chidinh*100/$count_sop.'%');
        }

        $this->template->load('index', 'view',$this->data);
	      
    }

    

    /**
    * Call Form to Add  New bvtv_tailieu_thamkhao
    *
    */
    public function add() 
    {
         if (!$this->ion_auth->logged_in() OR !$this->ion_auth->is_admin()) {
            redirect('Login');
        }

        $this->data['bvtv_tailieu_thamkhao']           = $this->bvtv_tailieu_thamkhaos->add();
        $this->data['action']            = 'bvtv_tailieu_thamkhao/save';
        
        //$this->template->js_add('','embed');
      
        $this->template->load('index', 'form',$this->data);
    }

    /**
    * Call Form to Modify bvtv_tailieu_thamkhao
    *
    */
    public function edit($id='') 
    {
         if (!$this->ion_auth->logged_in() OR !$this->ion_auth->is_admin()) {
            redirect('Login');
        }

        if ($id != '') 
        {

            $this->data['bvtv_tailieu_thamkhao']      = $this->bvtv_tailieu_thamkhaos->get_one($id);
            $this->data['action']       = 'bvtv_tailieu_thamkhao/save/' . $id;           
      
            //$this->template->js_add('','embed');
            
            $this->template->load('index', 'form',$this->data);
            
        }
        else 
        {
            $this->session->set_flashdata('notify', notify('Không thấy data','info'));
            redirect(site_url('bvtv_tailieu_thamkhao'));
        }
    }


    
    /**
    * Save & Update data  bvtv_tailieu_thamkhao
    *
    */
    public function save($id =NULL) 
    {
        
        // validation config
        $config = array(
                  
                    array(
                        'field' => 'tk_code',
                        'label' => 'Tk Code',
                        'rules' => 'trim|required'
                        ),
                    
                    array(
                        'field' => 'tk_name',
                        'label' => 'Tk Name',
                        'rules' => 'trim'
                        ),
                    
                    array(
                        'field' => 'tk_sop',
                        'label' => 'Tk Sop',
                        'rules' => 'trim'
                        ),
                    
                    array(
                        'field' => 'tk_chidinh',
                        'label' => 'Tk Chidinh',
                        'rules' => 'trim'
                        ),
                    
                    array(
                        'field' => 'tk_phuongphap',
                        'label' => 'Tk Phuongphap',
                        'rules' => 'trim'
                        ),
                    
                    array(
                        'field' => 'tk_hoaly',
                        'label' => 'Tk Hoaly',
                        'rules' => 'trim'
                        ),
                    
                    array(
                        'field' => 'tk_hoatchat',
                        'label' => 'Tk Hoatchat',
                        'rules' => 'trim'
                        ),
                    
                    array(
                        'field' => 'tk_link',
                        'label' => 'Tk Link',
                        'rules' => 'trim|required'
                        ),
                    
                    array(
                        'field' => 'tk_create',
                        'label' => 'Tk Create',
                        'rules' => 'trim'
                        ),
                    
                    array(
                        'field' => 'tk_user',
                        'label' => 'Tk User',
                        'rules' => 'trim'
                        ),
                    
                    array(
                        'field' => 'tk_note',
                        'label' => 'Tk Note',
                        'rules' => 'trim'
                        ),
                               
                  );
            
        // if id NULL then add new data
        if(!$id)
        {    
                  $this->form_validation->set_rules($config);

                  if ($this->form_validation->run() == TRUE) 
                  {
                      if ($this->input->post()) 
                      {
                          
                          $this->bvtv_tailieu_thamkhaos->save();
                          $this->session->set_flashdata('notify', notify('Thêm thành công','success'));
                          redirect('bvtv_tailieu_thamkhao');
                      }
                  } 
                  else // If validation incorrect 
                  {
                      $this->add();
                  }
         }
         else // Update data if Form Edit send Post and ID available
         {               
                $this->form_validation->set_rules($config);

                if ($this->form_validation->run() == TRUE) 
                {
                    if ($this->input->post()) 
                    {
                        $this->bvtv_tailieu_thamkhaos->update($id);
                        $this->session->set_flashdata('notify', notify('Update thành công','success'));
                        redirect('bvtv_tailieu_thamkhao');
                    }
                } 
                else // If validation incorrect 
                {
                    $this->edit($id);
                }
         }
    }
    
    /**
    * Detail bvtv_tailieu_thamkhao
    *
    */
    public function show($id='') 
    {
      

        if ($id != '') 
        {
            $this->data['bvtv_tailieu_thamkhao'] = $this->bvtv_tailieu_thamkhaos->get_one($id);            
            $this->template->load('index', 'show',$this->data);
            
        }
        else 
        {
            $this->session->set_flashdata('notify', notify('Không thấy data','info'));
            redirect(site_url('bvtv_tailieu_thamkhao'));
        }
    }
    
    /**
    * Delete bvtv_tailieu_thamkhao by ID
    *
    */
    public function destroy($id) 
    {        
         if (!$this->ion_auth->logged_in() OR !$this->ion_auth->is_admin()) {
            redirect('Login');
        }

        // ID phải lớn hơn 0
        if ($id>=0) 
        {
            $this->bvtv_tailieu_thamkhaos->destroy($id);           
            $this->session->set_flashdata('notify', notify('Xóa thành công','success'));
            redirect('bvtv_tailieu_thamkhao');
        }

    }

    public function viewFile($your_pdf_file)
    {
       
        $file = base64_decode($your_pdf_file);

        $this->output->set_content_type('application/pdf')->set_output(file_get_contents($file));
    }

  /*    public function maso() 
    {
    	$hc = array();
      
        $temp       = $this->bvtv_tailieu_thamkhaos->get_all();
        foreach ($temp as $key => $value) {
        	$s = explode('-', $value['tk_code']);
        	if(count($s) < 1){
        		$hc[] = '';
        	}elseif(count($s) < 2){
        		$c = count($s);
        		$vl = '';
        		for ($i=0; $i < $c; $i++) { 
        			$vl .= $s[$i];
        		}
        		$hc[] = $vl;
        	}else{
        		$c = count($s);
        		$vl = '';
        		for ($i=0; $i < $c-1; $i++) { 
        			$vl .= $s[$i].',';
        		}
        		$aa = rtrim(trim($vl), ',');
        		$hc[] =str_replace(',', '-', $aa);
        	}
        	
        	
        }
        foreach ($hc as $key => $value) {
        	$this->bvtv_tailieu_thamkhaos->update_hc($key+1, $value);
        	echo $key . ' : '. $value. '<br />';
        }
        //$this->template->load('index', 'view',$this->data);
	      
    }*/
}
?>