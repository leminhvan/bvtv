<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-xs-12 col-sm-6">
<div class="card">
    <?php echo form_open(site_url('bvtv_donvi/' . $action), 'id="form_bvtv_donvi" class="form-horizontal" role="form"'); ?>
        <div class="card-header">
            <h2><?php if(strpos(current_url(), 'add')) {echo lang('box_title_create');} else{echo lang('box_title_edit');} ?></h2>
        </div>
        
        <div class="card-body card-padding">
          
            <div class="form-group">
                <label  for="donvi_kyhieu" class="col-sm-3 control-label"><?php echo lang('donvi_kyhieu').'  <span class="c-red">*</span>'; ?></label>
                <div class="col-sm-8">
                    <div class="fg-line">
                        <?php                  
                          echo form_input(
                                array(
                                 'name'         => 'donvi_kyhieu',
                                 'id'           => 'donvi_kyhieu',                       
                                 'class'        => 'form-control   required',
                                 'maxlength'=>'15'
                                 ),
                                 set_value('donvi_kyhieu',$bvtv_donvi['donvi_kyhieu'])
                           );             
                        ?>
                         <?php echo form_error('donvi_kyhieu');?>
                    </div>
                </div>
            </div>
          
            <div class="form-group">
                <label  for="donvi_mota" class="col-sm-3 control-label"><?php echo lang('donvi_mota').' '; ?></label>
                <div class="col-sm-8">
                    <div class="fg-line">
                        <?php                  
                          echo form_input(
                                array(
                                 'name'         => 'donvi_mota',
                                 'id'           => 'donvi_mota',                       
                                 'class'        => 'form-control  ',
                                 'maxlength'=>'15'
                                 ),
                                 set_value('donvi_mota',$bvtv_donvi['donvi_mota'])
                           );             
                        ?>
                         <?php echo form_error('donvi_mota');?>
                    </div>
                </div>
            </div>
          
 
            <div class="form-group">
                <div class="col-sm-offset-4 col-sm-8">
                    <a href="<?php echo site_url('bvtv_donvi'); ?>" class="btn btn-primary btn-sm" ><?php echo lang('actions_back');?></a>
                    <button class="btn btn-primary btn-sm" type="submit"><?php echo lang('actions_save');?></button>
                </div>
            </div>

        </div>
    <?php echo form_close(); ?>  
</div>
<div class="col-sm-3"></div>
</div>