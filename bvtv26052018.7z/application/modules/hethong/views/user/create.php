<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-xs-12 col-sm-6">
<div class="card">
    <div class="card-header bgm-cyan">
            <h2 class="text-center"><?php if(strpos(current_url(), 'add')) {echo lang('box_title_create');} else{echo lang('box_title_edit');} ?></h2>
        </div>
        
        <div class="card-body card-padding">
                <?php echo form_open_multipart(current_url(), array('class' => 'form-horizontal', 'id' => 'form-create_user')); ?>
                    <div class="form-group">
                        <label  for="username" class="col-sm-3 control-label"><?php echo lang('username').'  <span class="c-red">*</span>'; ?></label>
                        <div class="col-sm-8">
                            <div class="fg-line">
                                <?php echo form_input($username);?>
                                <?php echo form_error('username');?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label  for="first_name" class="col-sm-3 control-label"><?php echo lang('first_name').'<span class="c-red">*</span> '; ?></label>
                        <div class="col-sm-8">
                            <div class="fg-line">
                                <?php echo form_input($first_name);?>
                                <?php echo form_error('first_name');?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label  for="gioitinh" class="col-sm-3 control-label"><?php echo lang('gioitinh'); ?></label>
                        <div class="col-sm-8" style="margin-top: 7px">
                                <label class="radio radio-inline m-r-20" style="padding-top: 0px">
                                    <input type="radio" name="gioitinh" <?php if (isset($gioitinh) && $gioitinh=="Nam") echo "checked";?> value="Nam">
                                    <i class="input-helper"></i> Nam 
                                </label>
                                <label class="radio radio-inline m-r-20" style="padding-top: 0px">
                                    <input type="radio" name="gioitinh" <?php if (isset($gioitinh) && $gioitinh=="Nữ") echo "checked";?> value="Nữ">
                                    <i class="input-helper"></i>  Nữ
                                </label>
                                <label class="radio radio-inline m-r-20" style="padding-top: 0px">
                                    <input type="radio" name="gioitinh" <?php if (isset($gioitinh) && $gioitinh=="Khác") echo "checked";?> value="Khác">
                                    <i class="input-helper"></i>  Khác
                                </label>
                                    <?php echo form_error('gioitinh');?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label  for="sinhnhat" class="col-sm-3 control-label"><?php echo lang('sinhnhat').' '; ?></label>
                            <div class="col-sm-8">
                                <div class="fg-line">
                                <?php echo form_input($sinhnhat);?>
                                <?php echo form_error('sinhnhat');?>
                                </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label  for="email" class="col-sm-3 control-label"><?php echo lang('email').'<span class="c-red">*</span> '; ?></label>
                            <div class="col-sm-8">
                                <div class="fg-line">
                                <?php echo form_input($email);?>
                                <?php echo form_error('email');?>
                                </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label  for="phone" class="col-sm-3 control-label"><?php echo lang('phone').' '; ?></label>
                            <div class="col-sm-8">
                                <div class="fg-line">
                                    <?php echo form_input($phone);?>
                                    <?php echo form_error('phone');?>
                                    <?php echo form_error('phone');?>
                                </div>
                            </div>
                        </div>

                    <div class="form-group">
                        <label  for="password" class="col-sm-3 control-label"><?php echo lang('password').'  <span class="c-red">*</span>'; ?></label>
                             <div class="col-sm-8">
                                <div class="fg-line">
                                    <?php echo form_input($password);?>
                                    <?php echo form_error('password');?>
                                    <div class="progress" style="margin:0">
                                        <div class="pwstrength_viewport_progress"></div>
                                    </div>
                               </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label  for="password_confirm" class="col-sm-3 control-label"><?php echo lang('password_confirm').'  <span class="c-red">*</span>'; ?></label>
                            <div class="col-sm-8">
                                <div class="fg-line">
                                    <?php echo form_input($password_confirm);?>
                                    <?php echo form_error('password_confirm');?>
                                    </div>
                        </div>
                    </div>


                    <label  for="avatar" class="col-sm-3 control-label"><?php echo lang('avatar').' '; ?></label>
                        <div class="fileinput fileinput-new" data-provides="fileinput">
                            <div class="fileinput-preview thumbnail" data-trigger="fileinput">
                            </div>
                            <div>
                                <span class="btn btn-info btn-file waves-effect waves-button waves-float">
                                    <span class="fileinput-new">Chọn ảnh</span>
                                    <span class="fileinput-exists">Change</span>
                                    <input type="file" id="avatar" name="avatar">
                                </span>
                            </div>
                        </div>
                  

                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
                            <a href="<?php echo site_url('hethong/users'); ?>" class="btn btn-primary btn-sm" ><?php echo lang('actions_back');?></a>
                            <button class="btn btn-primary btn-sm" type="submit"><?php echo lang('actions_save');?></button>
                        </div>
                    </div>
                </div>
    <?php echo form_close(); ?>  
</div>
<div class="col-sm-3"></div>
</div>